// ============================================================
// SafeSphere Content Script
// Injects the floating SafeGuide button and handles text
// context extraction for Reddit and generic pages.
// ============================================================

'use strict';

// ── Overlay element for the "Analyze with SafeSphere" right-click result ──
let overlayElement = null;
let lastAnalyzedText = '';


// ── Listen for messages from background.js ──────────────────────────────
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'analyze_text' && message.text) {
    lastAnalyzedText = message.text;
    showOverlay();
    fetchAnalysis(message.text);
    
    // Automatically trigger the chatbot popup window loaded with the analysis context
    const platform = detectPlatform();
    let context = '';
    if (window.location.hostname.includes('reddit.com')) {
      const selectedEl = getSelectedElement();
      context = extractRedditContext(message.text, selectedEl);
    } else {
      context = grabChatContext();
    }
    chrome.runtime.sendMessage({
      action:   'openSafeGuide',
      text:     message.text,
      platform,
      context,
    });
  } else if (message.action === 'get_chat_context') {
    let context = '';
    if (window.location.hostname.includes('reddit.com')) {
      const selectedEl = getSelectedElement();
      context = extractRedditContext(message.text || window.getSelection().toString(), selectedEl);
    } else {
      context = grabChatContext();
    }
    sendResponse({ context });
  }
  return true; // keep channel open for async sendResponse
});

// ── Helper: get the DOM element that contains the selection ─────────────
function getSelectedElement() {
  const sel = window.getSelection();
  if (!sel || sel.rangeCount === 0) return null;
  let node = sel.getRangeAt(0).commonAncestorContainer;
  return node.nodeType !== Node.ELEMENT_NODE ? node.parentElement : node;
}

// ── Detect platform from current URL ────────────────────────────────────
function detectPlatform() {
  const h = window.location.hostname;
  if (h.includes('instagram.com'))                       return 'Instagram';
  if (h.includes('discord.com'))                         return 'Discord';
  if (h.includes('whatsapp.com'))                        return 'WhatsApp';
  if (h.includes('reddit.com'))                          return 'Reddit';
  if (h.includes('twitter.com') || h.includes('x.com')) return 'X (Twitter)';
  if (h.includes('facebook.com'))                        return 'Facebook';
  if (h.includes('snapchat.com'))                        return 'Snapchat';
  if (h.includes('telegram.org'))                        return 'Telegram';
  if (h.includes('tiktok.com'))                          return 'TikTok';
  return 'Webpage';
}

// ── Grab last 5 visible chat/message elements as context ────────────────
function grabChatContext() {
  const selectors = [
    '[class*="messageContent"]',
    '.copyable-text',
    'div[role="row"] span',
    'div[data-testid="post-container"] p',
    '.Comment p',
    '.message',
    '.chat-message',
    '.msg-content',
    'div[class*="message" i]',
  ];
  for (const sel of selectors) {
    try {
      const els = Array.from(document.querySelectorAll(sel))
        .map(el => el.textContent.trim())
        .filter(t => t.length > 0);
      if (els.length > 0) return els.slice(-5).join('\n');
    } catch (_) {}
  }
  // Generic paragraph fallback
  return Array.from(document.querySelectorAll('p'))
    .map(el => el.textContent.trim())
    .filter(t => t.length > 5 && t.length < 500)
    .slice(-5)
    .join('\n');
}

// ── Reddit-specific deep context extraction ──────────────────────────────
function extractRedditContext(selectedText, element) {
  if (!element) element = document.body;

  // Post title
  let postTitle = 'Unknown Post Title';
  for (const sel of ['shreddit-title', 'h1[id^="post-title-"]', 'h1', 'title']) {
    const el = document.querySelector(sel);
    if (el) { postTitle = (el.getAttribute('title') || el.textContent).trim(); break; }
  }

  // Subreddit
  let subreddit = 'r/unknown';
  const pathMatch = window.location.pathname.match(/\/r\/([a-zA-Z0-9_]+)/);
  if (pathMatch) subreddit = `r/${pathMatch[1]}`;

  // Author & surrounding text
  let author = 'unknown_user';
  let surrounding = element.textContent.trim().substring(0, 300);
  const commentEl = element.closest('shreddit-comment, div[data-testid="comment"], div.comment');
  if (commentEl) {
    author = commentEl.getAttribute('author') ||
      (commentEl.querySelector('a[href*="/user/"]')?.textContent.replace('u/', '').trim()) ||
      'unknown_user';
  }

  return [
    'Reddit Thread Analysis Context',
    `Subreddit: ${subreddit}`,
    `Post Title: "${postTitle}"`,
    `Author: u/${author}`,
    `Selected: "${selectedText}"`,
    `Surrounding: "${surrounding}"`,
  ].join('\n');
}

// ── Init Reddit MutationObserver (lazy-loaded comments) ─────────────────
function initRedditObserver() {
  if (!window.location.hostname.includes('reddit.com')) return;
  new MutationObserver(() => {}).observe(document.body, { childList: true, subtree: true });
}
initRedditObserver();

// ============================================================
// OVERLAY — "Analyze with SafeSphere" right-click result card
// ============================================================
function showOverlay() {
  if (overlayElement) overlayElement.remove();
  overlayElement = document.createElement('div');
  overlayElement.id = 'safesphere-overlay-root';
  overlayElement.innerHTML = `
    <div class="ss-card">
      <div class="ss-header">
        <div class="ss-title-container">
          <div class="ss-logo-dot"></div>
          <h2 class="ss-title">SafeSphere</h2>
        </div>
        <button class="ss-close-btn" id="ss-close-btn">&times;</button>
      </div>
      <div id="ss-content">
        <div class="ss-loading">
          <div class="ss-spinner"></div>
          <p>Analyzing…</p>
        </div>
      </div>
    </div>`;
  document.body.appendChild(overlayElement);
  document.getElementById('ss-close-btn').addEventListener('click', () => {
    overlayElement?.remove();
    overlayElement = null;
  });
}

async function fetchAnalysis(text) {
  try {
    const data = await new Promise((resolve, reject) => {
      chrome.runtime.sendMessage({ action: 'proxy_fetch', text }, res => {
        if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
        if (res?.error) return reject(new Error(res.error));
        resolve(res.data);
      });
    });
    renderOverlayResults(data);
  } catch (err) {
    renderOverlayError('Failed to connect to backend: ' + err.message);
  }
}

// ... render Overlay functions ...
function renderOverlayResults(data) {
  const el = document.getElementById('ss-content');
  if (!el) return;
  const level  = data.severity?.level || 'UNKNOWN';
  const reason = data.severity?.reason || '';
  const threats = (data.threats || []).filter(t => t.score >= 20)
    .sort((a, b) => b.score - a.score)
    .map(t => `<li class="ss-threat-badge">${t.label} (${t.score}%)</li>`)
    .join('') || '<li class="ss-threat-badge safe">No Threats Detected</li>';
  const actions = (data.actionItems?.immediateActions || [])
    .slice(0, 3).map(a => `<li>${a}</li>`).join('') || '<li>Stay vigilant.</li>';
  el.innerHTML = `
    <div class="ss-result-section">
      <h3 class="ss-label">Severity</h3>
      <h4 class="ss-severity ${level}">${level}</h4>
      <p class="ss-reason">${reason}</p>
    </div>
    <div class="ss-result-section">
      <h3 class="ss-label">Detected Patterns</h3>
      <ul class="ss-threat-list">${threats}</ul>
    </div>
    <div class="ss-result-section">
      <h3 class="ss-label">Recommended Actions</h3>
      <ul class="ss-action-list">${actions}</ul>
    </div>
    <div class="ss-result-section" style="text-align: center; background: transparent; border: none; padding-top: 10px; padding-bottom: 0;">
      <button id="ss-chat-guide-btn" style="
        background: linear-gradient(135deg, #4A6CF7 0%, #6C5CE7 100%);
        color: white;
        border: none;
        padding: 10px 18px;
        border-radius: 20px;
        cursor: pointer;
        font-weight: 600;
        font-size: 13px;
        box-shadow: 0 4px 12px rgba(74, 108, 247, 0.3);
        transition: transform 0.2s, box-shadow 0.2s;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        outline: none;
      ">🛡️ Chat with SafeGuide AI</button>
    </div>`;

  const chatBtn = document.getElementById('ss-chat-guide-btn');
  if (chatBtn) {
    chatBtn.addEventListener('mouseenter', () => chatBtn.style.transform = 'scale(1.05)');
    chatBtn.addEventListener('mouseleave', () => chatBtn.style.transform = '');
    chatBtn.addEventListener('click', () => {
      const selectedText = window.getSelection().toString().trim();
      const platform = detectPlatform();
      const context = window.location.hostname.includes('reddit.com')
        ? extractRedditContext(selectedText, getSelectedElement())
        : grabChatContext();
      
      chrome.runtime.sendMessage({
        action:   'openSafeGuide',
        text:     selectedText || lastAnalyzedText,
        platform,
        context,
      });
    });
  }
}

function renderOverlayError(msg) {
  const el = document.getElementById('ss-content');
  if (!el) return;
  el.innerHTML = `<div class="ss-result-section" style="background:#fef2f2;border-color:#fecaca;">
    <h3 class="ss-label" style="color:#b91c1c;">Analysis Failed</h3>
    <p class="ss-reason" style="color:#991b1b;">${msg}</p>
  </div>`;
}

// ============================================================
// FLOATING BUTTON — bottom-LEFT, brand gradient, draggable
// ============================================================
(function injectFloatingButton() {
  // Guard: only inject once per page
  if (document.getElementById('safeguide-floating-btn')) return;

  const btn = document.createElement('div');
  btn.id = 'safeguide-floating-btn';
  btn.setAttribute('role', 'button');
  btn.setAttribute('aria-label', 'Open SafeGuide AI Assistant');
  btn.setAttribute('tabindex', '0');
  btn.innerHTML = '🛡️';
  btn.title = 'SafeGuide — Digital Safety Assistant';

  // ── Core styles (inline to override any host-page CSS) ──
  Object.assign(btn.style, {
    position:     'fixed',
    bottom:       '20px',
    left:         '20px',       // LEFT side
    right:        'auto',
    width:        '60px',
    height:       '60px',
    borderRadius: '50%',
    // Brand gradient: #4A6CF7 → #6C5CE7
    background:   'linear-gradient(135deg, #4A6CF7 0%, #6C5CE7 100%)',
    boxShadow:    '0 6px 20px rgba(74, 108, 247, 0.45), inset 0 2px 4px rgba(255,255,255,0.18)',
    border:       '2px solid rgba(255,255,255,0.25)',
    display:      'flex',
    alignItems:   'center',
    justifyContent:'center',
    fontSize:     '28px',
    color:        '#ffffff',
    cursor:       'grab',
    zIndex:       '999999',
    userSelect:   'none',
    WebkitUserSelect: 'none',
    pointerEvents: 'auto',
    touchAction:  'none',
    boxSizing:    'border-box',
    transition:   'transform 0.2s cubic-bezier(0.175,0.885,0.32,1.275), box-shadow 0.2s',
    // Subtle white glow so it's visible on dark pages too
    outline:      '1.5px solid rgba(255,255,255,0.15)',
  });

  // ── Hover effects ────────────────────────────────────────
  btn.addEventListener('mouseenter', () => {
    btn.style.transform  = 'scale(1.12)';
    btn.style.boxShadow  = '0 10px 30px rgba(74,108,247,0.65), inset 0 2px 4px rgba(255,255,255,0.25)';
  });
  btn.addEventListener('mouseleave', () => {
    if (!isDragging) {
      btn.style.transform = '';
      btn.style.boxShadow = '0 6px 20px rgba(74,108,247,0.45), inset 0 2px 4px rgba(255,255,255,0.18)';
    }
  });

  // ── Restore saved position ───────────────────────────────
  chrome.storage.local.get(['sg_btn_left', 'sg_btn_top'], pos => {
    if (pos.sg_btn_top !== undefined && pos.sg_btn_left !== undefined) {
      const maxTop  = window.innerHeight - 70;
      const maxLeft = window.innerWidth  - 70;
      btn.style.top    = Math.min(pos.sg_btn_top,  maxTop)  + 'px';
      btn.style.left   = Math.min(pos.sg_btn_left, maxLeft) + 'px';
      btn.style.bottom = 'auto';
    }
  });

  // ── Drag state ───────────────────────────────────────────
  let isDragging  = false;
  let hasMoved    = false;
  let startX = 0, startY = 0;
  let initLeft = 0, initTop = 0;

  function startDrag(clientX, clientY) {
    const rect = btn.getBoundingClientRect();
    startX   = clientX;
    startY   = clientY;
    initLeft = rect.left;
    initTop  = rect.top;
    isDragging = true;
    hasMoved   = false;
    btn.style.transition = 'none';
    btn.style.cursor     = 'grabbing';
  }

  function onDragMove(clientX, clientY) {
    if (!isDragging) return;
    const dx = clientX - startX;
    const dy = clientY - startY;
    if (Math.abs(dx) > 3 || Math.abs(dy) > 3) hasMoved = true;

    const maxLeft = window.innerWidth  - 70;
    const maxTop  = window.innerHeight - 70;
    const newLeft = Math.max(10, Math.min(initLeft + dx, maxLeft));
    const newTop  = Math.max(10, Math.min(initTop  + dy, maxTop));

    btn.style.left   = newLeft + 'px';
    btn.style.top    = newTop  + 'px';
    btn.style.bottom = 'auto';
    btn.style.right  = 'auto';
  }

  function endDrag() {
    if (!isDragging) return;
    isDragging = false;
    btn.style.transition = '';
    btn.style.cursor     = 'grab';

    // Persist position
    const rect = btn.getBoundingClientRect();
    chrome.storage.local.set({ sg_btn_left: rect.left, sg_btn_top: rect.top });

    if (!hasMoved) handleClick();
  }

  // Mouse events
  btn.addEventListener('mousedown', e => {
    if (e.button !== 0) return;
    e.preventDefault();
    startDrag(e.clientX, e.clientY);
    document.addEventListener('mousemove', onMouseMove);
    document.addEventListener('mouseup',   onMouseUp);
  });
  function onMouseMove(e) { onDragMove(e.clientX, e.clientY); }
  function onMouseUp()    {
    endDrag();
    document.removeEventListener('mousemove', onMouseMove);
    document.removeEventListener('mouseup',   onMouseUp);
  }

  // Touch events
  btn.addEventListener('touchstart', e => {
    const t = e.touches[0];
    startDrag(t.clientX, t.clientY);
  }, { passive: true });
  btn.addEventListener('touchmove', e => {
    const t = e.touches[0];
    onDragMove(t.clientX, t.clientY);
  }, { passive: true });
  btn.addEventListener('touchend', endDrag);

  // Keyboard accessibility
  btn.addEventListener('keydown', e => {
    if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); handleClick(); }
  });

  // ── Click handler — open SafeGuide ──────────────────────
  function handleClick() {
    const selectedText = window.getSelection().toString().trim();
    if (selectedText) {
      const platform = detectPlatform();
      const context  = window.location.hostname.includes('reddit.com')
        ? extractRedditContext(selectedText, getSelectedElement())
        : grabChatContext();
      chrome.runtime.sendMessage({
        action:   'openSafeGuide',
        text:     selectedText,
        platform,
        context,
      });
    } else {
      chrome.runtime.sendMessage({ action: 'openSafeGuide' });
    }
  }

  // ── Inject into page ─────────────────────────────────────
  function inject() {
    if (!document.getElementById('safeguide-floating-btn')) {
      document.body.appendChild(btn);
    }
  }
  if (document.body) inject();
  else document.addEventListener('DOMContentLoaded', inject);
})();
