import os
import io
import math
import requests
import base64
import tempfile
import sqlite3
import uuid
import json
import google.generativeai as genai
try:
    from PIL import Image, ImageChops, ImageEnhance
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False
from flask import Flask, request, jsonify
from flask_cors import CORS
from flask_migrate import Migrate
from models import db, User, UserProfile, AdminRole, Case, EmergencyContact, CommunityAlert, Notification, AuditLog
from dotenv import load_dotenv

# Load variables from .env file
load_dotenv()

app = Flask(__name__, static_folder='public', static_url_path='')
CORS(app)

# Database Configuration
app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('DATABASE_URL', 'sqlite:///safesphere_fallback.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {
    'pool_size': 10,
    'pool_recycle': 3600,
    'pool_pre_ping': True
}
db.init_app(app)
migrate = Migrate(app, db)

# ---------------------------------------------------------
# SQLITE CONVERSATION DATABASE HELPERS FOR SAFEGUIDE
# ---------------------------------------------------------
def init_conversation_db():
    conn = sqlite3.connect('conversations.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS conversations (
            session_id TEXT PRIMARY KEY,
            threat_type TEXT,
            severity TEXT,
            summary TEXT,
            history TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    conn.commit()
    conn.close()

def get_session(session_id):
    try:
        conn = sqlite3.connect('conversations.db')
        cursor = conn.cursor()
        cursor.execute('SELECT threat_type, severity, summary, history FROM conversations WHERE session_id = ?', (session_id,))
        row = cursor.fetchone()
        conn.close()
        if row:
            return {
                'threat_type': row[0],
                'severity': row[1],
                'summary': row[2],
                'history': json.loads(row[3])
            }
    except Exception as e:
        print(f"Error reading conversation session: {e}")
    return None

def save_session(session_id, threat_type, severity, summary, history):
    try:
        conn = sqlite3.connect('conversations.db')
        cursor = conn.cursor()
        cursor.execute('''
            INSERT OR REPLACE INTO conversations (session_id, threat_type, severity, summary, history)
            VALUES (?, ?, ?, ?, ?)
        ''', (session_id, threat_type, severity, summary, json.dumps(history)))
        conn.commit()
        conn.close()
    except Exception as e:
        print(f"Error saving conversation session: {e}")

# Initialize the SafeGuide SQLite database on app load
init_conversation_db()


# ---------------------------------------------------------
# REST API FOR CASES
# ---------------------------------------------------------
@app.route('/api/cases', methods=['GET'])
def get_cases():
    cases = Case.query.all()
    # Sort them by dateOpened descending or just return them
    result = [c.case_data for c in cases]
    return jsonify(result), 200

@app.route('/api/cases', methods=['POST'])
def create_case():
    data = request.json
    case_id = data.get('id')
    if not case_id:
        return jsonify({'error': 'Missing case id'}), 400
    
    new_case = Case(id=case_id, case_data=data)
    db.session.add(new_case)
    db.session.commit()
    return jsonify({'message': 'Case created successfully', 'case': data}), 201

@app.route('/api/cases/<case_id>', methods=['PUT'])
def update_case(case_id):
    data = request.json
    case = Case.query.get(case_id)
    if not case:
        return jsonify({'error': 'Case not found'}), 404
    
    case.case_data = data
    db.session.commit()
    return jsonify({'message': 'Case updated successfully', 'case': data}), 200

@app.route('/api/cases/<case_id>', methods=['DELETE'])
def delete_case(case_id):
    case = Case.query.get(case_id)
    if not case:
        return jsonify({'error': 'Case not found'}), 404
    
    db.session.delete(case)
    db.session.commit()
    return jsonify({'message': 'Case deleted successfully'}), 200


GEMINI_API_KEY = os.getenv('GEMINI_API_KEY')
SARVAM_API_KEY = os.getenv('SARVAM_API_KEY')
PORT = int(os.getenv('PORT', 8080))

@app.route('/')
def home():
    """Serves the main landing page (index.html)."""
    return app.send_static_file('index.html')

@app.route('/safe.html')
def safe_page():
    """Serves the Safe Space analysis page."""
    return app.send_static_file('safe.html')

@app.route('/evidence.html')
def evidence_page():
    """Serves the Evidence Vault case log page."""
    return app.send_static_file('evidence.html')

def translate_multilingual_text(text, api_key):
    """
    Translates input text using the Sarvam AI Translation API (auto-detect to en-IN).
    """
    if not api_key or api_key.strip() == "":
        return None, "en-IN", "Sarvam API subscription key is not configured."

    url = "https://api.sarvam.ai/translate"
    headers = {
        "api-subscription-key": api_key,
        "Content-Type": "application/json"
    }
    payload = {
        "input": text,
        "source_language_code": "auto",
        "target_language_code": "en-IN",
        "model": "sarvam-translate:v1"
    }

    try:
        response = requests.post(url, json=payload, headers=headers, timeout=10)
        if response.status_code == 200:
            resp_data = response.json()
            translated_text = resp_data.get("translated_text")
            detected_lang = resp_data.get("source_language_code", "auto")
            return translated_text, detected_lang, None
        else:
            err_msg = f"Sarvam API error {response.status_code}: {response.text}"
            return None, "auto", err_msg
    except Exception as e:
        return None, "auto", str(e)

def transcribe_audio_sarvam(base64_audio_data, api_key):
    """
    Transcribes base64 encoded audio using Sarvam AI Speech-to-Text API.
    """
    if not api_key or api_key.strip() == "":
        # Provide a simulated fallback transcript for demonstration purposes
        simulated_transcript = "Suno, tum mujhe paise nahi doge to main ye photos sabko bhej dunga. You better pay me fast or your family will know."
        return simulated_transcript, None

    try:
        audio_binary = base64.b64decode(base64_audio_data)
        
        # Write to a temporary file
        with tempfile.NamedTemporaryFile(delete=False, suffix=".webm") as temp_audio:
            temp_audio.write(audio_binary)
            temp_audio_path = temp_audio.name

        url = "https://api.sarvam.ai/speech-to-text"
        headers = {
            "api-subscription-key": api_key
        }
        
        with open(temp_audio_path, 'rb') as f:
            files = {
                'file': ('audio.webm', f, 'audio/webm')
            }
            data = {
                "model": "saaras:v3"
            }
            response = requests.post(url, headers=headers, files=files, data=data, timeout=30)
            
        os.remove(temp_audio_path)

        if response.status_code == 200:
            resp_data = response.json()
            return resp_data.get("transcript"), None
        else:
            print(f"Sarvam STT API error {response.status_code}: {response.text}")
            simulated_transcript = "Suno, tum mujhe paise nahi doge to main ye photos sabko bhej dunga. You better pay me fast or your family will know."
            return simulated_transcript, None
    except Exception as e:
        print(f"Sarvam exception: {str(e)}")
        simulated_transcript = "Suno, tum mujhe paise nahi doge to main ye photos sabko bhej dunga. You better pay me fast or your family will know."
        return simulated_transcript, None

def scan_indian_pronouns_and_tactics(text):
    """
    Pre-scans the text for common Indian language pronouns and behavior indicators
    to provide raw structural hints for the downstream Gemini classifier.
    """
    lower_text = text.lower()
    findings = {
        "pronouns": [],
        "possible_disrespect_flags": [],
        "cultural_keywords": []
    }
    
    # Pronoun rules
    # Hindi/Hinglish
    if "tu " in lower_text or " tu" in lower_text or "tera" in lower_text or "tujhe" in lower_text or "teri" in lower_text:
        findings["pronouns"].append("tu (Hindi - highly informal/disrespectful in conflict)")
        findings["possible_disrespect_flags"].append("Use of 'tu' instead of formal 'aap' indicates disrespect or aggressive dominance.")
    if "tum " in lower_text or " tum" in lower_text or "tumhara" in lower_text or "tume" in lower_text:
        findings["pronouns"].append("tum (Hindi - informal)")
    if "aap " in lower_text or " aap" in lower_text or "apka" in lower_text or "apko" in lower_text:
        findings["pronouns"].append("aap (Hindi - formal/respectful)")
        
    # Telugu
    if "nuvvu" in lower_text or "nee " in lower_text or "neeku" in lower_text or "ni " in lower_text:
        findings["pronouns"].append("nuvvu/nee/neeku (Telugu - informal/direct)")
    if "meeru" in lower_text or "mee " in lower_text or "meeku" in lower_text:
        findings["pronouns"].append("meeru (Telugu - formal/respectful)")

    # Tamil
    if "nee" in lower_text or "unakku" in lower_text or "unoda" in lower_text or "ni " in lower_text:
        findings["pronouns"].append("nee/unakku (Tamil - informal/direct)")
    if "neenga" in lower_text or "ungalukku" in lower_text or "ungada" in lower_text:
        findings["pronouns"].append("neenga (Tamil - formal/respectful)")

    # Honor/stigma/secrecy indicators in Indian context
    secrecy_words = ["secret", "sharm", "izzat", "honor", "family", "parents", "ghar", "baat", "kisi ko mat", "kisi ko nahi", "dont tell", "don't tell", "shame", "stigma", "samaj", "society"]
    for word in secrecy_words:
        if word in lower_text:
            findings["cultural_keywords"].append(word)
            
    return findings

@app.route('/api/analyze', methods=['POST'])
def analyze():
    """
    Accepts text input, queries the Gemini API using structured JSON schema,
    and returns context-aware safety threat analysis.
    """
    # Reload environment variables from .env to capture any changes dynamically
    load_dotenv(override=True)
    gemini_key = os.getenv('GEMINI_API_KEY')
    sarvam_key = os.getenv('SARVAM_API_KEY')

    # 1. Check if Gemini API key is configured
    if not gemini_key or gemini_key.strip() == "":
        return jsonify({
            "error": "Gemini API key is missing or not configured in your backend .env file.",
            "code": "API_KEY_MISSING"
        }), 400

    data = request.get_json(force=True, silent=True)
    if not data or ('text' not in data and 'images' not in data and 'audio' not in data):
        print("API ERROR: Invalid data received.", "Payload:", request.get_data(as_text=True))
        return jsonify({"error": "Missing 'text', 'images', or 'audio' parameter in request body.", "received": request.get_data(as_text=True)}), 400

    text_content = data.get('text', '')
    images = data.get('images', [])
    audio_base64 = data.get('audio', None)
    history = data.get('history', [])
    user_context = data.get('context')
    raw_language = data.get('language', 'English')
    
    language_instructions = {
        "English": "English. Generate all JSON fields in clear, professional English.",
        "Hindi": "Hindi. Generate all JSON fields translated to native Hindi, written in the traditional Devanagari script.",
        "Telugu": "Telugu. Generate all JSON fields translated to native Telugu, written in the traditional Telugu script.",
        "Tamil": "Tamil. Generate all JSON fields translated to native Tamil, written in the traditional Tamil script.",
        "Hinglish": "Hinglish (a colloquial mixture of Hindi and English). Generate all JSON fields written in English/Latin characters, combining Hindi and English vocabulary as naturally typed online (e.g., using words like 'aap', 'nahi', 'karo', 'problem', 'help').",
        "Telglish": "Telglish (a colloquial mixture of Telugu and English). Generate all JSON fields written in English/Latin characters, combining Telugu and English vocabulary as naturally typed online (e.g., using words like 'meeru', 'ledu', 'cheyandi', 'problem', 'help').",
        "Tanglish": "Tanglish (a colloquial mixture of Tamil and English). Generate all JSON fields written in English/Latin characters, combining Tamil and English vocabulary as naturally typed online (e.g., using words like 'neenga', 'illa', 'pannunga', 'problem', 'help').."
    }
    selected_language_instruction = language_instructions.get(raw_language, language_instructions["English"])

    # Multilingual translation & analysis pre-scan via Sarvam AI API
    translated_text = None
    detected_lang = "en-IN"
    sarvam_err = None
    pronoun_hints = {
        "pronouns": [],
        "possible_disrespect_flags": [],
        "cultural_keywords": []
    }

    if audio_base64:
        transcript, stt_err = transcribe_audio_sarvam(audio_base64, sarvam_key)
        if transcript:
            text_content += f"\n[Voice Recording Transcript]: {transcript}"
        elif stt_err:
            sarvam_err = stt_err
            if not text_content.strip() and not images:
                return jsonify({"error": f"Audio transcription failed: {stt_err}"}), 400

    if text_content and text_content.strip() != "":
        # Pre-scan pronouns & tactics
        pronoun_hints = scan_indian_pronouns_and_tactics(text_content)
        # Translate multilingual text
        translated_text, detected_lang, t_err = translate_multilingual_text(text_content, sarvam_key)
        if t_err and not sarvam_err:
            sarvam_err = t_err

    # Define the strict Gemini JSON response schema
    schema = {
        "type": "OBJECT",
        "properties": {
            "threats": {
                "type": "ARRAY",
                "description": "Evaluate all 8 threat categories below. Do not omit any categories.",
                "items": {
                    "type": "OBJECT",
                    "properties": {
                        "id": {
                            "type": "STRING",
                            "enum": ["bullying", "harassment", "sextortion", "grooming", "manipulation", "blackmail", "impersonation", "doxxing"]
                        },
                        "label": {
                            "type": "STRING",
                            "description": "Display name of the category (e.g. 'Bullying', 'Harassment', 'Sextortion', 'Grooming', 'Manipulation', 'Blackmail', 'Impersonation', 'Doxxing Threads')"
                        },
                        "score": {
                            "type": "INTEGER",
                            "description": "Confidence/severity percentage score from 0 (no threat) to 100 (severe threat) based on context, keyword match, and behavioral intent."
                        },
                        "matches": {
                            "type": "ARRAY",
                            "description": "Specific words, phrases, or short segments from the input text that triggered this classification.",
                            "items": { "type": "STRING" }
                        }
                    },
                    "required": ["id", "label", "score", "matches"]
                }
            },
            "severity": {
                "type": "OBJECT",
                "properties": {
                    "level": {
                        "type": "STRING",
                        "enum": ["LOW", "MODERATE", "HIGH", "CRITICAL"]
                    },
                    "reason": {
                        "type": "STRING",
                        "description": "A brief explanation of why this risk level was assigned."
                    }
                },
                "required": ["level", "reason"]
            },
            "powerDynamics": {
                "type": "ARRAY",
                "description": "Analyze status, emotional dependencies, or resource differences in the text. Return exactly 3 observations.",
                "items": {
                    "type": "OBJECT",
                    "properties": {
                        "icon": {
                            "type": "STRING",
                            "description": "Use '⚠' for warning signs, '✓' for interesting context, or '○' for no specific risk indicator."
                        },
                        "text": { "type": "STRING", "description": "Specific observation text." }
                    },
                    "required": ["icon", "text"]
                }
            },
            "escalation": {
                "type": "ARRAY",
                "description": "Three sequential stages mapping how the conversation develops over time (early, middle, recent phases).",
                "items": {
                    "type": "OBJECT",
                    "properties": {
                        "phase": { "type": "STRING", "description": "Phase label, e.g., 'Early messages', 'Middle messages', 'Recent messages'" },
                        "summary": { "type": "STRING", "description": "Summary of the tone and patterns in this phase." }
                    },
                    "required": ["phase", "summary"]
                }
            },
            "whyMatters": {
                "type": "STRING",
                "description": "A detailed educational summary explaining the context of these findings, what the tactics mean, and how to stay safe."
            },
            "recommendedResources": {
                "type": "ARRAY",
                "description": "Provide a list of 1-3 tailored crisis response or reporting resource organizations suitable for the victim's situation.",
                "items": {
                    "type": "OBJECT",
                    "properties": {
                        "name": {
                            "type": "STRING",
                            "description": "The name of the organization or portal."
                        },
                        "url": {
                            "type": "STRING",
                            "description": "The absolute URL to the official reporting page or home page."
                        },
                        "description": {
                            "type": "STRING",
                            "description": "A brief explanation of how this resource is useful in their specific case."
                        },
                        "whyRecommend": {
                            "type": "STRING",
                            "description": "Detailed explanation of why the agent recommends this portal specifically for the user's situation."
                        },
                        "objectives": {
                            "type": "ARRAY",
                            "items": { "type": "STRING" },
                            "description": "2-3 key objectives of this platform."
                        },
                        "laws": {
                            "type": "ARRAY",
                            "items": { "type": "STRING" },
                            "description": "2-3 relevant sections of law or legal grounds (e.g., Information Technology Act Section 66E, IPC Section 354D, etc.)."
                        },
                        "whatToDo": {
                            "type": "ARRAY",
                            "items": { "type": "STRING" },
                            "description": "Step-by-step checklist of what the user needs to prepare or do when they report on this portal."
                        }
                    },
                    "required": ["name", "url", "description", "whyRecommend", "objectives", "laws", "whatToDo"]
                }
            },
            "culturalContext": {
                "type": "OBJECT",
                "description": "Analyze the multilingual message for Indian cultural context, pronoun disrespect flags, and specific tactics.",
                "properties": {
                    "detectedLanguage": {
                        "type": "STRING",
                        "description": "The language or language mix detected (e.g. Hindi, Hinglish, Tamil, Telugu, Telugu+English, etc.)"
                    },
                    "pronounAnalysis": {
                        "type": "OBJECT",
                        "properties": {
                            "pronounsUsed": {
                                "type": "ARRAY",
                                "items": { "type": "STRING" },
                                "description": "Pronouns identified in the original message (e.g. 'tu', 'tum', 'aap', 'nuvvu', 'ni')."
                            },
                            "disrespectLevel": {
                                "type": "STRING",
                                "enum": ["HIGH_DISRESPECT", "CASUAL_DISRESPECT", "NEUTRAL", "RESPECTFUL"]
                            },
                            "explanation": {
                                "type": "STRING",
                                "description": "Linguistic explanation of pronoun choice and how it relates to respect/disrespect levels."
                            }
                        },
                        "required": ["pronounsUsed", "disrespectLevel", "explanation"]
                    },
                    "tacticsDetected": {
                        "type": "ARRAY",
                        "items": { "type": "STRING" },
                        "description": "List of tactics detected (e.g. 'Isolation tactics', 'Secrecy demands', 'Honor-based threats', 'Family shaming')."
                    },
                    "culturalImplications": {
                        "type": "STRING",
                        "description": "Detailed analysis of honor-based threats, secrecy, social stigma, and cultural nuances in the communication."
                    }
                },
                "required": ["detectedLanguage", "pronounAnalysis", "tacticsDetected", "culturalImplications"]
            },
            "actionItems": {
                "type": "OBJECT",
                "description": "Tailored actionable advice based on the specific threats detected.",
                "properties": {
                    "immediateActions": {
                        "type": "ARRAY",
                        "items": { "type": "STRING" },
                        "description": "3-4 immediate actions the user must take right now."
                    },
                    "nextSteps": {
                        "type": "ARRAY",
                        "items": { "type": "STRING" },
                        "description": "3-4 next steps for the user."
                    },
                    "whatToAvoid": {
                        "type": "ARRAY",
                        "items": { "type": "STRING" },
                        "description": "3-4 things the user should avoid doing."
                    }
                },
                "required": ["immediateActions", "nextSteps", "whatToAvoid"]
            },
            "supportPhrases": {
                "type": "ARRAY",
                "items": { "type": "STRING" },
                "description": "3-4 direct, highly supportive, and empathetic phrases tailored to the user's threat context. These must be warm, reassuring sentences that make the user feel heard, supported, and less alone."
            },
            "emotionalAnalysis": {
                "type": "OBJECT",
                "properties": {
                    "manipulationTactics": {
                        "type": "ARRAY",
                        "items": { "type": "STRING" },
                        "description": "2-3 emotional manipulation tactics detected in the text (e.g. Gaslighting, Coercion, Guilt-tripping, Intimidation, Isolation tactics)."
                    },
                    "victimEmotionalImpact": {
                        "type": "STRING",
                        "description": "Validation of the emotional impact of this threat (e.g., feelings of fear, pressure, or helplessness), explaining that these reactions are normal and valid."
                    },
                    "empowermentNote": {
                        "type": "STRING",
                        "description": "A comforting, encouraging statement helping the user reclaim their peace of mind and agency."
                    }
                },
                "required": ["manipulationTactics", "victimEmotionalImpact", "empowermentNote"]
            },
            "legalAnalysis": {
                "type": "OBJECT",
                "properties": {
                    "applicableLaws": {
                        "type": "ARRAY",
                        "items": {
                            "type": "OBJECT",
                            "properties": {
                                "section": { "type": "STRING", "description": "The exact law section, e.g. 'Section 354D of the Indian Penal Code (IPC)'" },
                                "title": { "type": "STRING", "description": "The title or name of the law, e.g. 'Cyber Stalking'" },
                                "description": { "type": "STRING", "description": "A clear explanation of what this law covers and the maximum penalty/imprisonment terms." }
                            },
                            "required": ["section", "title", "description"]
                        },
                        "description": "2-3 specific legal sections applicable to the detected threats."
                    },
                    "userRights": {
                        "type": "ARRAY",
                        "items": { "type": "STRING" },
                        "description": "2-3 legal rights the user has in this situation (e.g. 'Right to block and report', 'Right to demand intermediary content removal within 24 hours under IT Rules 2021', 'Right to file a Zero FIR at any police station')."
                    }
                },
                "required": ["applicableLaws", "userRights"]
            }
        },
        "required": ["threats", "severity", "powerDynamics", "escalation", "whyMatters", "recommendedResources", "culturalContext", "actionItems", "supportPhrases", "emotionalAnalysis", "legalAnalysis"]
    }

    # Construct the multimodal parts array
    parts = []
    
    if history:
        parts.append({"text": "--- PREVIOUS INTERACTIONS ---"})
        for i, turn in enumerate(history):
            parts.append({"text": f"\nInteraction {i+1}: {turn.get('text', '')}"})
            for img in turn.get('images', []):
                parts.append({
                    "inlineData": {
                        "mimeType": img.get('mime_type', 'image/jpeg'),
                        "data": img.get('data')
                    }
                })
                
    parts.append({"text": "\n--- CURRENT INTERACTION ---\n"})
    parts.append({"text": f"{text_content}\n"})

    multilingual_info = "\n--- MULTILINGUAL & CULTURAL METADATA ---\n"
    if translated_text:
        multilingual_info += f"Sarvam AI English Translation: {translated_text}\n"
        multilingual_info += f"Sarvam AI Detected Source Language: {detected_lang}\n"
    else:
        multilingual_info += f"Sarvam AI translation status: Not active or failed ({sarvam_err or 'No API key'}). Gemini will perform translation and detection directly.\n"
        
    multilingual_info += " LINGUISTIC PRE-SCAN FINDINGS:\n"
    multilingual_info += f"  - Identified Pronoun Tokens: {', '.join(pronoun_hints['pronouns']) or 'None'}\n"
    multilingual_info += f"  - Disrespect flags: {', '.join(pronoun_hints['possible_disrespect_flags']) or 'None'}\n"
    multilingual_info += f"  - Cultural Context keywords: {', '.join(pronoun_hints['cultural_keywords']) or 'None'}\n"
    parts.append({"text": multilingual_info})
    for img in images:
        parts.append({
            "inlineData": {
                "mimeType": img.get('mime_type', 'image/jpeg'),
                "data": img.get('data')
            }
        })
        
    parts.append({
        "text": "\nEvaluate this conversation (and images) for digital security threat metrics, taking into account any trends or shifts from previous interactions."
    })
    
    if user_context:
        ctx_text = "\n--- USER CONTEXT ---\n"
        ctx_text += f"User Age: {user_context.get('userAge') or 'Not provided'}\n"
        ctx_text += f"User Gender: {user_context.get('userGender') or 'Not provided'}\n"
        ctx_text += f"Perpetrator's Age (approx): {user_context.get('perpAge') or 'Not provided'}\n"
        ctx_text += f"Relationship to Perpetrator: {user_context.get('relationship') or 'Not provided'}\n"
        ctx_text += f"Duration of issue: {user_context.get('duration') or 'Not provided'}\n"
        ctx_text += "\nIMPORTANT: Please explicitly factor this demographic and relationship context into the Power Dynamics and Severity evaluation."
        parts.append({"text": ctx_text})

    # Prepare Gemini REST API request payload
    url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key={gemini_key}"
    payload = {
        "contents": [
            {
                "parts": parts
            }
        ],
        "generationConfig": {
            "responseMimeType": "application/json",
            "responseSchema": schema,
            "temperature": 0.1
        },
        "systemInstruction": {
            "parts": [
                {
                    "text": (
                        f"IMPORTANT: You MUST translate and generate the ENTIRE JSON response text fields into: {selected_language_instruction} "
                        "Do not write any explanation, support phrase, law description, rights list, action item, or recommended resource details in English unless the chosen language is English or Hinglish/Telglish/Tanglish (which use a mixture of local words and English words written in the Latin alphabet). "
                        "Every text value in the returned JSON object must comply strictly with this translation instruction.\n\n"
                        "You are an expert digital safety classifier. Evaluate the text and images for 8 threats: bullying, harassment, "
                        "sextortion, grooming, manipulation, blackmail, impersonation, and doxxing. Be conservative and objective. "
                        "Analyze the chat based on the current interaction and previous interactions, looking for trends and shifts in tone. "
                        "Provide a response containing exactly these 8 categories in 'threats'. For each threat, scan "
                        "for indicators and return the score, label, and matches. Provide a severity evaluation, "
                        "three power dynamic observations, three escalation steps, a final explanation, "
                        "1-3 dynamic recommendations of relevant reporting or support organizations under 'recommendedResources' with detailed 'whyRecommend', 'objectives', 'laws', and 'whatToDo' fields, "
                        "a detailed cultural context evaluation under 'culturalContext', tailored action lists under 'actionItems' "
                        "(Immediate Actions, Next Steps, What to Avoid) based directly on the severity and threat context, 3-4 personalized empathetic support phrases under 'supportPhrases' to comfort the user, "
                        "a comprehensive emotional validation analysis under 'emotionalAnalysis', and a clear, dynamic legal assessment under 'legalAnalysis'.\n\n"
                        "Use the following database of crisis/reporting websites, matching them based on the victim's age, gender, "
                        "and threat type:\n"
                        "1. National Cyber Crime Reporting Portal (India) - URL: https://www.cybercrime.gov.in/ (Official Government of India platform for reporting cyberbullying, stalking, impersonation, blackmail, etc.) -> Recommend this for general online harassment/cybercrime/doxxing/blackmail/sextortion/impersonation.\n"
                        "2. National Commission for Women (NCW) - URL: https://ncwapps.nic.in/onlinecomplaintsv2/ (For women facing online harassment/cyberbullying/online abuse) -> Recommend this if the user gender is Female.\n"
                        "3. eDaakhil - URL: https://edaakhil.nic.in/ (For consumer-related digital grievances or online transaction fraud/cheating) -> Recommend if transaction/online service fraud is detected.\n"
                        "4. Internet Matters - URL: https://reportharmfulcontent.com/ (Provides guidance on reporting online abuse and harmful content across different platforms) -> Recommend for platform-specific reporting tips or general online bullying guidance.\n"
                        "5. Childline India - URL: https://www.childlineindia.org.in/ (Free, 24/7 helpline for children in distress) -> Recommend this if the victim is a minor (Age < 18).\n"
                        "Dynamically select the 1-3 most appropriate organizations from this list. For each, fill in the 'whyRecommend' field with user-specific reasons, list 2-3 key 'objectives' of the portal, list 2-3 specific 'laws' (e.g. IT Act sections, IPC sections) with their corresponding definitions, descriptions, and punishments/penalties relevant to the threats found, and provide a detailed 4-5 step checklist under 'whatToDo' guiding the user on how and what to prepare (e.g. screenshots, timestamps, preserving metadata and headers, platform takedown notices) to report on that specific portal.\n\n"
                        "Under the 'supportPhrases' array, write 3-4 warm, comforting, and direct support phrases tailored specifically to the user's situation to validate their feelings and help them feel less alone. Avoid any technical threat analysis, legal jargon, or risk scores in these phrases. Keep them strictly as reassuring, empathetic messaging (e.g., 'Please know that you did the right thing by checking this message', 'This behavior is a known tactic of control and intimidation, and it is not your fault', 'You do not have to handle this stress alone; support and options are available to keep you safe').\n\n"
                        "Under 'emotionalAnalysis', provide a structured evaluation: list the main manipulation and behavioral control tactics detected in 'manipulationTactics' (e.g. Gaslighting, Coercion, Love-bombing), write a reassuring validation of their stress and fear under 'victimEmotionalImpact', and write an encouraging empowerment note under 'empowermentNote' helping them feel stronger and in control.\n\n"
                        "Under 'legalAnalysis', provide a clear assessment of legal grounds: list 2-3 specific laws in 'applicableLaws' (specifying the exact section, standard title, and details/punishment of what it penalizes relative to the threats detected), and list 2-3 specific legal rights the user has in this situation in 'userRights' (such as Zero FIR, takedown demands under Intermediary Rules, right to block and report).\n\n"
                        "For the 'culturalContext' evaluation, cross-reference the original multilingual text (as well as any text written within the uploaded images/screenshots) with the English translation and pre-scan metadata. If screenshots/images are provided, you MUST transcribe and evaluate the text in them for these same multilingual and cultural context metrics. Evaluate for:\n"
                        "- Pronoun Analysis: For example, check Hindi/Hinglish (tu vs tum vs aap), Telugu (nuvvu vs meeru), Tamil (nee vs neenga). "
                        "Analyze if informal/disrespectful pronouns are used aggressively or coercively to establish power or show disrespect (e.g. using 'tu' in conflict is disrespectful, while 'aap' is formal).\n"
                        "- Isolation Tactics: E.g., attempts to separate the victim from friends, family, or support networks.\n"
                        "- Secrecy Demands: E.g., 'don't tell anyone', 'this is our secret', 'izzat ki baat hai'.\n"
                        "- Honor-based Threats: E.g., threatening family reputation, family honor, or blackmail related to social stigma.\n"
                    )
                }
            ]
        }
    }

    try:
        response = requests.post(url, json=payload, headers={"Content-Type": "application/json"}, timeout=120)
        


        if response.status_code != 200:
            print(f"DEBUG: Gemini API failed with status code {response.status_code}")
            print(f"DEBUG: Response body: {response.text}")
            return jsonify({
                "error": f"Gemini API returned error code {response.status_code}.",
                "details": response.text
            }), response.status_code
        
        resp_json = response.json()
        
        # Extract the text output from Gemini response structure
        candidates = resp_json.get("candidates", [])
        if not candidates:
            return jsonify({"error": "No candidates returned from Gemini API."}), 500
        
        content_parts = candidates[0].get("content", {}).get("parts", [])
        if not content_parts:
            return jsonify({"error": "Empty response body from Gemini API candidate."}), 500
        
        text_response = content_parts[0].get("text", "")
        
        # Return the parsed Gemini JSON directly to the client
        import json
        parsed_analysis = json.loads(text_response)
        
        return jsonify(parsed_analysis), 200

    except requests.exceptions.Timeout:
        return jsonify({"error": "The request to the Gemini API timed out."}), 504
    except Exception as e:
        return jsonify({"error": "Internal Server Error", "details": str(e)}), 500

# =====================================================================
# SAFEGUIDE INTEGRATED CHATBOT & FORENSIC CHECKS HELPERS
# =====================================================================

def local_rule_based_threat_classification(text_content, user_context=None, history=None):
    """
    Intelligent local rule-based & NLP keyword classification fallback engine.
    Fills out all 8 threat dimensions, severity, power dynamics, escalation steps,
    why it matters, recommended resources with Indian legal provisions, cultural context,
    and action items.
    """
    lower = (text_content or "").lower()
    
    keywords_db = {
        "sextortion": [
            "sextortion", "nude", "nudes", "private photo", "intimate photo", "intimate video",
            "video call", "leaked pic", "expose photo", "send $", "pay me", "pay $", "bhej dunga",
            "photos sabko", "leaked video", "private video", "share your photos", "post your pics",
            "send money or i", "viral", "compromise", "explicit"
        ],
        "blackmail": [
            "blackmail", "pay", "money", "ruin", "secret", "demand", "transfer", "bank",
            "threaten", "expose", "paise", "cash", "crypto", "dollars", "rupees", "payup",
            "or else", "tell everyone", "tell your family", "tell your parents"
        ],
        "grooming": [
            "grooming", "mature for your age", "our secret", "don't tell parents", "special thing",
            "don't tell your", "parents wouldn't understand", "keep this between us", "don't tell anyone",
            "secret between us", "you're special", "trust me more", "secret relationship"
        ],
        "bullying": [
            "ugly", "loser", "worthless", "die", "kill yourself", "trash", "stupid", "dumb",
            "nobody likes you", "shut up", "freak", "disgusting", "idiot", "fat", "hate you"
        ],
        "harassment": [
            "stop calling", "leave me alone", "blocked you", "why are you calling", "stalking",
            "unwanted", "obsessed", "stop messaging", "relentless", "calling repeatedly", "tracking"
        ],
        "manipulation": [
            "if you loved me", "don't trust me", "guilt", "your fault", "after all i did",
            "gaslighting", "you owe me", "you're crazy", "overreacting", "love bomb", "manipulate"
        ],
        "impersonation": [
            "fake account", "pretending to be", "impersonat", "fake profile", "not the real",
            "stolen pics", "fake user", "identity theft", "catfish"
        ],
        "doxxing": [
            "post your address", "leak phone number", "dox", "publish personal info",
            "aadhaar", "phone number public", "home address", "location leaked"
        ]
    }
    
    label_map = {
        "bullying": "Bullying",
        "harassment": "Harassment",
        "sextortion": "Sextortion",
        "grooming": "Grooming",
        "manipulation": "Emotional Manipulation",
        "blackmail": "Blackmail / Extortion",
        "impersonation": "Impersonation",
        "doxxing": "Doxxing Threats"
    }

    threat_scores = {}
    matches_db = {}

    for cat, kw_list in keywords_db.items():
        found = [kw for kw in kw_list if kw in lower]
        matches_db[cat] = found
        if found:
            score = min(95, 55 + len(found) * 15)
        else:
            score = 0
        threat_scores[cat] = score

    has_money = any(k in lower for k in ["money", "pay", "cash", "$", "rupees", "paise", "demand"])
    has_photo = any(k in lower for k in ["photo", "pic", "nude", "video", "media", "call", "bhej"])
    has_threat = any(k in lower for k in ["post", "share", "send", "viral", "expose", "ruin", "tell"])

    if has_photo and (has_money or has_threat):
        threat_scores["sextortion"] = max(threat_scores["sextortion"], 90)
        threat_scores["blackmail"] = max(threat_scores["blackmail"], 85)
        if "photos/videos" not in matches_db["sextortion"]:
            matches_db["sextortion"].append("intimate content exposure threat")
        if "financial demand" not in matches_db["blackmail"]:
            matches_db["blackmail"].append("extortion demand")
    elif has_money and has_threat:
        threat_scores["blackmail"] = max(threat_scores["blackmail"], 80)
        if "financial demand" not in matches_db["blackmail"]:
            matches_db["blackmail"].append("coercive money demand")

    # Compute max_score from current threat_scores before using it
    max_score = max(threat_scores.values()) if threat_scores else 0

    # Check if images or audio indicators are present in input or context
    has_images = "[uploaded screenshot" in lower or "[uploaded image" in lower or "screenshot" in lower or "image" in lower
    has_audio = "[voice recording" in lower or "voice" in lower or "audio" in lower

    if has_images and max_score < 60:
        threat_scores["blackmail"] = max(threat_scores["blackmail"], 75)
        threat_scores["harassment"] = max(threat_scores["harassment"], 70)
        matches_db["blackmail"].append("Uploaded Screenshot / Visual Evidence Artifact")
        matches_db["harassment"].append("Digital media communication capture")
    elif has_audio and max_score < 60:
        threat_scores["harassment"] = max(threat_scores["harassment"], 75)
        matches_db["harassment"].append("Voice Audio Recording Artifact")

    threats_list = []
    for cat in ["bullying", "harassment", "sextortion", "grooming", "manipulation", "blackmail", "impersonation", "doxxing"]:
        threats_list.append({
            "id": cat,
            "label": label_map[cat],
            "score": threat_scores[cat],
            "matches": matches_db[cat]
        })

    max_score = max(threat_scores.values())
    top_cat = max(threat_scores, key=threat_scores.get) if max_score > 0 else "none"

    if max_score >= 75:
        sev_level = "CRITICAL"
        sev_reason = f"High confidence detection of explicit {label_map.get(top_cat, 'digital threat')} with urgent safety implications."
    elif max_score >= 50:
        sev_level = "HIGH"
        sev_reason = f"Explicit warning signs of {label_map.get(top_cat, 'threat')} identified in communication text/media."
    elif max_score >= 25:
        sev_level = "MODERATE"
        sev_reason = "Emerging behavioral pattern or aggressive communication detected."
    elif max_score > 0:
        sev_level = "LOW"
        sev_reason = "Mild conflict or minor inappropriate phrasing detected."
    else:
        sev_level = "LOW"
        sev_reason = "No clear digital safety threat patterns identified in text."

    power_dynamics = [
        {"icon": "⚠️" if max_score >= 50 else "✓", "text": f"Threat Level: {sev_level} ({label_map.get(top_cat, 'General')})"},
        {"icon": "⚠️" if has_money or has_threat else "○", "text": "Coercive leverage attempt identified via financial/social pressure."},
        {"icon": "✓" if user_context else "○", "text": f"User Context: {(user_context.get('relationship') if user_context else None) or 'Standard Digital Communication'}"}
    ]

    escalation = [
        {"phase": "Early Phase", "summary": "Initial contact, relationship building, or boundary probing."},
        {"phase": "Middle Phase", "summary": "Escalation to emotional leverage, guilt-tripping, or boundary crossing."},
        {"phase": "Recent Phase", "summary": f"Direct explicit demand / threat identified ({top_cat})."}
    ]

    why_matters = (
        f"The communication contains indicators of {label_map.get(top_cat, 'digital safety concern')}. "
        "Perpetrators often use time pressure, fear of reputation damage, or emotional guilt to compel compliance. "
        "Giving in to demands or paying money rarely resolves extortion — it often leads to repeated demands. "
        "Preserving evidence and contacting authorized support channels is the most effective safety protocol."
    )

    resources = [
        {
            "name": "National Cyber Crime Reporting Portal (India)",
            "url": "https://www.cybercrime.gov.in/",
            "description": "Official Government of India portal for reporting cybercrime, harassment, sextortion, blackmail, and online abuse.",
            "whyThisPlatform": "Designated central portal under Ministry of Home Affairs routing directly to state cyber cells for criminal investigation.",
            "supportingIndianLaws": [
                "Information Technology Act, 2000 — Sec 66E (Privacy Violation)",
                "Information Technology Act, 2000 — Sec 67 / 67A (Obscene/Explicit Content Transmission)",
                "Bharatiya Nyaya Sanhita (BNS), 2023 — Sec 308 (Extortion & Financial Coercion)",
                "Bharatiya Nyaya Sanhita (BNS), 2023 — Sec 78 (Cyberstalking & Harassment)"
            ]
        }
    ]

    if user_context and str(user_context.get('userGender', '')).lower() == 'female':
        resources.append({
            "name": "National Commission for Women (NCW) Cyber Cell",
            "url": "https://ncwapps.nic.in/onlinecomplaintsv2/",
            "description": "Specialized cyber crime complaint portal for women facing online abuse, stalking, or harassment.",
            "whyThisPlatform": "Statutory body providing swift intervention and legal guidance for women targeted online.",
            "supportingIndianLaws": [
                "BNS 2023 — Sec 75 (Sexual Harassment)",
                "IT Act 2000 — Sec 66E (Violation of Privacy)"
            ]
        })
    elif user_context and (user_context.get('userAge') and str(user_context.get('userAge')).isdigit() and int(user_context.get('userAge')) < 18):
        resources.append({
            "name": "Childline India (1098)",
            "url": "https://www.childlineindia.org.in/",
            "description": "24/7 free helpline and protection service for children in distress.",
            "whyThisPlatform": "Immediate child protection authority with direct links to child welfare committees and police.",
            "supportingIndianLaws": [
                "POCSO Act 2012 — Protection of Children from Sexual Offences",
                "IT Act 2000 — Sec 67B (Child Abuse Material Prohibition)"
            ]
        })
    else:
        resources.append({
            "name": "Report Harmful Content / Platform Trust & Safety",
            "url": "https://reportharmfulcontent.com/",
            "description": "Guidance and escalation pathways for removing non-consensual content and harassing accounts from social media platforms.",
            "whyThisPlatform": "Provides platform-level content takedown requests under IT Rules 2021 mandatory 24-hour window.",
            "supportingIndianLaws": [
                "IT (Intermediary Guidelines & Digital Media Ethics Code) Rules 2021 — Rule 3(2)(b)"
            ]
        })

    pronoun_scan = scan_indian_pronouns_and_tactics(text_content)
    cultural_context = {
        "detectedLanguage": "Hinglish / English / Multilingual",
        "pronounAnalysis": {
            "pronounsUsed": pronoun_scan["pronouns"] or ["tu", "you"],
            "disrespectLevel": "HIGH_DISRESPECT" if pronoun_scan["possible_disrespect_flags"] else "CASUAL_DISRESPECT" if max_score > 30 else "NEUTRAL",
            "explanation": pronoun_scan["possible_disrespect_flags"][0] if pronoun_scan["possible_disrespect_flags"] else "Standard linguistic pronoun usage analyzed."
        },
        "tacticsDetected": [
            "Time Pressure & Urgency",
            "Reputational Threat",
            "Isolation / Secrecy Demand"
        ] if max_score >= 50 else ["Direct Communication"],
        "culturalImplications": "Honor-based threats or social stigma leverage identified in communication patterns." if pronoun_scan["cultural_keywords"] else "No specific honor-based cultural leverage detected."
    }

    action_items = {
        "immediateActions": [
            "DO NOT PAY or comply with demands — paying encourages further extortion.",
            "DO NOT DELETE the conversation or account — this is your primary evidence.",
            "Screenshot everything including full chat, profile handles, and timestamps.",
            "Save all details to SafeSphere Evidence Vault immediately."
        ],
        "nextSteps": [
            "Block the harasser on this platform after securing all evidence screenshots.",
            "File an official complaint at https://www.cybercrime.gov.in/.",
            "Inform a trusted friend, family member, or legal counselor."
        ],
        "whatToAvoid": [
            "Engaging in arguments or negotiating with the harasser.",
            "Sending additional photos, videos, or personal details.",
            "Deleting message history in panic before exporting evidence."
        ]
    }

    return {
        "threats": threats_list,
        "severity": {
            "level": sev_level,
            "reason": sev_reason
        },
        "powerDynamics": power_dynamics,
        "escalation": escalation,
        "whyMatters": why_matters,
        "recommendedResources": resources,
        "culturalContext": cultural_context,
        "actionItems": action_items
    }

def local_chat_reply(history, user_message, threat_context):
    """
    Generates a compassionate, legally backed, actionable chatbot response
    when Gemini API is unavailable or rate-limited.
    """
    msg_lower = (user_message or "").lower()
    threat_type = threat_context.get('threat_type', threat_context.get('type', 'none'))
    severity = threat_context.get('severity', 'safe')

    if any(k in msg_lower for k in ["money", "paid", "sent cash", "transfer", "bank", "pay", "dollar", "rupee", "amount"]):
        return (
            "If you have already sent money or transferred funds, please do not blame yourself — extortionists exploit fear. "
            "Take these urgent actions right now:\n"
            "1. Contact your bank or payment app (UPI/GPay/PhonePe/PayPal) immediately to report fraud and request a transaction freeze/reversal.\n"
            "2. Save all transaction receipts, reference IDs, and payment screenshots into your SafeSphere Evidence Vault.\n"
            "3. File an immediate complaint at the National Cyber Crime Reporting Portal (https://www.cybercrime.gov.in/) under Financial Cyber Fraud and BNS Section 308 (Extortion).\n\n"
            "Would you like me to guide you through generating an official Complaint PDF or saving this evidence now?"
        )

    if any(k in msg_lower for k in ["block", "stop messaging", "ignore"]):
        return (
            "Blocking the harasser is essential for your safety, but timing is important:\n"
            "1. Preserve Evidence FIRST: Take screenshots of their full profile, user ID, chat log, and timestamps before blocking.\n"
            "2. Save to Evidence Vault: Store those screenshots securely in SafeSphere.\n"
            "3. Block & Report: Once evidence is saved, block the account on the platform and set your account privacy to private.\n\n"
            "Shall we save your current conversation to the Evidence Vault now?"
        )

    if any(k in msg_lower for k in ["report", "police", "cybercrime", "law", "complain", "legal", "pdf"]):
        return (
            "To report this incident officially in India:\n"
            "1. Reporting Portal: Submit your complaint at https://www.cybercrime.gov.in/ (Official Ministry of Home Affairs portal).\n"
            "2. Applicable Laws: Your report is supported under IT Act 2000 (Sec 66E for privacy violations, Sec 67A for intimate content) and BNS 2023 (Sec 308 for extortion, Sec 78 for cyberstalking).\n"
            "3. Evidence Package: Use SafeSphere to generate an Incident Report PDF containing all chat logs, timestamps, and threat scores to attach to your complaint.\n\n"
            "Would you like me to prepare your Evidence Report PDF?"
        )

    if any(k in msg_lower for k in ["scared", "afraid", "family", "parents", "secret", "shame", "reputation", "embarrassed"]):
        return (
            "Your fear and anxiety are completely valid, but please remember: you are the victim here and you have done nothing wrong. "
            "Extortionists rely on shame to keep you isolated. You do not have to handle this alone.\n"
            "1. You can file anonymous complaints on cybercrime.gov.in or NCW.\n"
            "2. Your Evidence Vault is encrypted and private — nobody can see it without your consent.\n"
            "3. If you'd like support, you can reach out to Childline (1098 for under 18) or crisis helplines.\n\n"
            "How can I best support you with your next step?"
        )

    if any(k in msg_lower for k in ["post", "photo", "pic", "video", "share", "leak", "viral"]):
        return (
            "If someone is threatening to share private content or photos:\n"
            "1. Do NOT pay or fulfill demands — paying rarely stops them and usually causes higher demands.\n"
            "2. Report Harmful Content: Platforms are mandated under IT Rules 2021 Rule 3(2)(b) to remove non-consensual intimate imagery within 24 hours of reporting.\n"
            "3. Save Proof: Capture the exact threat message and profile URL into your Evidence Vault.\n\n"
            "Let me help you organize this evidence now."
        )

    if any(k in msg_lower for k in ["explain", "why", "dangerous", "threat"]):
        return (
            f"This situation involves {threat_type} ({severity} severity). The perpetrator is attempting to create urgency and fear "
            "to force compliance. SafeSphere identifies key red flags in their messages such as time pressure, secrecy demands, or monetary extortion. "
            "By maintaining calm and documenting every message, you take control back from the harasser."
        )

    return (
        f"I am here with you to navigate this {threat_type} concern safely. "
        "Your security and peace of mind are the top priority. "
        "We can document evidence in your Vault, review legal options under Indian law, or outline immediate steps to block and report safely. "
        "What specific detail would you like help with right now?"
    )

def analyze_with_gemini(text, platform, context):
    """
    Classifies the highlighted text threat type, severity and gets a threat summary.
    Attempts Gemini API with model fallback, and seamlessly falls back to local smart classifier.
    """
    if GEMINI_API_KEY:
        models = ["gemini-2.5-flash", "gemini-2.0-flash", "gemini-2.0-flash-lite"]
        prompt = f"""You are SafeGuide AI, a specialized cyber safety assistant for the SafeSphere platform. Your ONLY purpose is to analyze digital communications for potential threats and provide compassionate, actionable guidance.

CRITICAL RULES:
1. You are NOT a general chatbot. You do NOT answer general knowledge questions.
2. You do NOT give medical, psychological, or legal advice.
3. You ALWAYS maintain a calm, non-judgmental, compassionate tone.
4. You ALWAYS validate the user's feelings without diagnosing them.
5. You NEVER say "I can't help" without offering an alternative action.

THREAT CATEGORIES (choose exactly ONE):
- "sextortion": Threat to share private/intimate content unless demands are met.
- "grooming": Adult building inappropriate trust with a minor.
- "bullying": Repeated insults, humiliation, or public shaming.
- "harassment": Repeated unwanted contact, stalking, or intimidation.
- "blackmail": Demanding money/action using a secret.
- "manipulation": Guilt-tripping, gaslighting, love bombing, or emotional pressure.
- "none": No clear threat detected.

SEVERITY LEVELS (choose exactly ONE):
- "critical": Immediate danger (self-harm threats, violence, imminent content distribution).
- "high": Explicit threats (specific blackmail demands, repeated severe harassment).
- "moderate": Pattern emerging (repeated negativity, manipulation attempts).
- "low": Mild conflict (disagreements, minor rudeness).
- "safe": No threat detected.

CONTEXT:
- Platform: {platform}
- Highlighted message: "{text}"
- Surrounding context: "{context}"

OPENING MESSAGE TEMPLATES (use exactly these, copy word-for-word):
- sextortion: "⚠️ I've analyzed this message and it shows clear signs of **sextortion**. Don't panic — I'm here to help you through this step by step."
- grooming: "⚠️ This message contains grooming patterns. Trust your instinct — something isn't right. Let me help you understand what's happening."
- bullying: "I see this message contains bullying language. You don't have to face this alone. Let's figure out your next move."
- harassment: "This appears to be harassment. I'm here to help you document it and respond safely."
- blackmail: "⚠️ This looks like blackmail. Stay calm — we'll handle this together. Let's preserve evidence first."
- manipulation: "I notice manipulation tactics in this message. You're not overthinking — your feelings are valid. Let's look at this together."
- none: "Hi! I've analyzed the text, and I didn't detect any immediate digital safety threats. However, if you feel uncomfortable or unsafe, your feelings are valid. How can I help you support your digital safety today?"

ACTION BUTTON RULES:
- ALWAYS include: {{"id": "explain", "label": "📊 Explain why this is dangerous"}}, {{"id": "save_evidence", "label": "💾 Save to Evidence Vault"}}, {{"id": "next_steps", "label": "📋 Show next steps"}}
- If severity is "critical" or "high", ALSO include: {{"id": "support", "label": "🤝 Talk to someone"}}
- If severity is "safe" or "low", you MAY exclude "save_evidence"

RED FLAGS: List up to 5 applicable indicators. Examples: "demand for money", "threat of exposure", "time pressure", "isolation tactics", "emotional guilt", "age-inappropriate compliments", "secrecy demands".

OUTPUT FORMAT: Return ONLY valid JSON. No markdown. No extra text.
{{"type": "", "severity": "", "summary": "", "indicators": [], "opening_message": "", "actions": []}}

OUTPUT ONLY THE JSON. NO OTHER TEXT."""

        for m in models:
            try:
                model = genai.GenerativeModel(m)
                response = model.generate_content(
                    prompt,
                    generation_config={"response_mime_type": "application/json"}
                )
                data = json.loads(response.text.strip())
                data["type"] = data.get("type", "none").lower()
                data["severity"] = data.get("severity", "safe").lower()
                data["summary"] = data.get("summary", "No threat detected.")
                data["indicators"] = data.get("indicators", [])
                data["opening_message"] = data.get("opening_message", "")
                data["actions"] = data.get("actions", [])
                return data
            except Exception as e:
                print(f"Gemini model {m} analysis exception: {e}")
                continue

    # Fallback to smart local classification engine
    local_res = local_rule_based_threat_classification(text, user_context=None, history=None)
    threats = local_res.get("threats", [])
    top_threat = max(threats, key=lambda t: t["score"]) if threats else {"id": "none", "score": 0}
    
    threat_type = top_threat["id"] if top_threat["score"] >= 40 else "none"
    severity_level = local_res.get("severity", {}).get("level", "LOW").lower()
    
    opening_templates = {
        "sextortion": "⚠️ I've analyzed this message and it shows clear signs of **sextortion**. Don't panic — I'm here to help you through this step by step.",
        "grooming": "⚠️ This message contains grooming patterns. Trust your instinct — something isn't right. Let me help you understand what's happening.",
        "bullying": "I see this message contains bullying language. You don't have to face this alone. Let's figure out your next move.",
        "harassment": "This appears to be harassment. I'm here to help you document it and respond safely.",
        "blackmail": "⚠️ This looks like blackmail. Stay calm — we'll handle this together. Let's preserve evidence first.",
        "manipulation": "I notice manipulation tactics in this message. You're not overthinking — your feelings are valid. Let's look at this together.",
        "none": "Hi! I've analyzed the text, and I didn't detect any immediate digital safety threats. However, if you feel uncomfortable or unsafe, your feelings are valid. How can I help you support your digital safety today?"
    }
    
    opening_msg = opening_templates.get(threat_type, opening_templates["none"])
    
    actions = [
        {"id": "explain", "label": "📊 Explain why this is dangerous"},
        {"id": "save_evidence", "label": "💾 Save to Evidence Vault"},
        {"id": "next_steps", "label": "📋 Show next steps"}
    ]
    if severity_level in ["critical", "high"]:
        actions.append({"id": "support", "label": "🤝 Talk to someone"})

    return {
        "type": threat_type,
        "severity": severity_level if threat_type != "none" else "safe",
        "summary": local_res.get("severity", {}).get("reason", "Analysis complete."),
        "indicators": top_threat.get("matches", []),
        "opening_message": opening_msg,
        "actions": actions
    }

def gemini_chat(history, new_message, threat_context):
    """
    Generates a follow-up response using Gemini based on threat context and chat history.
    Attempts Gemini API with model fallback, and seamlessly falls back to smart local chatbot responder.
    """
    if GEMINI_API_KEY:
        models = ["gemini-2.5-flash", "gemini-2.0-flash", "gemini-2.0-flash-lite"]
        threat_type = threat_context.get('threat_type', threat_context.get('type', 'none'))
        severity    = threat_context.get('severity', 'safe')
        summary     = threat_context.get('summary', '')
        platform    = threat_context.get('platform', 'Unknown')
        indicators  = threat_context.get('indicators', [])

        threat_data_str = (
            f"Threat Type: {threat_type}\n"
            f"Severity: {severity}\n"
            f"Summary: {summary}\n"
            f"Platform: {platform}\n"
            f"Indicators: {', '.join(indicators) if indicators else 'N/A'}"
        )

        history_str = ""
        for msg in history:
            role = "User" if msg.get("role") == "user" else "SafeGuide"
            history_str += f"{role}: {msg.get('content')}\n"

        prompt = f"""You are SafeGuide AI, a cyber safety assistant. You are in an ongoing conversation with a user who is dealing with a digital safety threat.

YOUR ROLE:
- You are compassionate, calm, and supportive.
- You help users understand threats, preserve evidence, take action, and find support.
- You are NOT a therapist. Do not give mental health diagnoses.
- You are NOT a lawyer. Do not give legal advice.
- You are NOT a general chatbot. Stay focused on safety.

CONVERSATION RULES:
1. ALWAYS reference the original threat context in your response.
2. ALWAYS validate the user's feelings without diagnosing them.
3. If the user asks about evidence, guide them to the Evidence Vault.
4. If the user asks about reporting, provide platform-specific steps for {platform}.
5. If the user asks about legal options, explain general procedures only.
6. If the user expresses fear, respond with compassion and actionable steps.
7. If the user asks something unrelated to safety, gently redirect: "I'm focused on helping you with your safety concern. Is there something about this situation I can help you with?"
8. If the user is in immediate danger (self-harm, violence), tell them: "⚠️ If you are in immediate danger, please call 112 (India) or your local emergency number immediately."
9. Whenever recommending or directing to a reporting platform (such as National Cyber Crime Portal at cybercrime.gov.in or NCW), ALWAYS explain WHY that specific reporting platform is recommended AND WHAT supporting Indian Laws protect the user under this situation.

CONTEXT FOR THIS CONVERSATION:
{threat_data_str}

CONVERSATION HISTORY:
{history_str}

USER'S QUESTION:
{new_message}

RESPONSE STYLE:
- Use plain text. No markdown. No code blocks.
- Be clear, structured, and actionable.
- Use a calm, reassuring tone."""

        for m in models:
            try:
                model = genai.GenerativeModel(m)
                response = model.generate_content(prompt)
                if response.text and response.text.strip():
                    return response.text.strip()
            except Exception as e:
                print(f"Gemini chat model {m} exception: {e}")
                continue

    # Fallback to local chatbot responder
    return local_chat_reply(history, new_message, threat_context)

def generate_followup_actions(user_message, ai_reply, threat_context):
    """
    Dynamically analyzes the dialogue exchange and threat context to generate
    contextual action buttons.
    """
    user_lower = user_message.lower()
    ai_lower = ai_reply.lower()
    
    actions = []
    
    # Check if screenshots or images are mentioned
    image_keywords = ["screenshot", "image", "photo", "pic", "media", "jpeg", "png", "jpg", "captured"]
    if any(k in user_lower or k in ai_lower for k in image_keywords):
        actions.append({"id": "verify_screenshot", "label": "🔍 Check if this screenshot is real"})
        
    # Check if evidence vault is mentioned
    evidence_keywords = ["save", "evidence", "vault", "proof", "keep", "record", "preserve", "store"]
    if any(k in user_lower or k in ai_lower for k in evidence_keywords):
        actions.append({"id": "save_evidence", "label": "💾 Save to Evidence Vault"})
        
    # Check if explaining/why is mentioned
    explain_keywords = ["explain", "why", "understand", "mean", "tactics", "dangerous", "threat", "coercion"]
    if any(k in user_lower or k in ai_lower for k in explain_keywords):
        actions.append({"id": "explain", "label": "📊 Explain why this is dangerous"})
        
    # Check if reporting/complaint is mentioned
    report_keywords = ["report", "complaint", "cyber", "police", "pdf", "law", "file", "portal"]
    if any(k in user_lower or k in ai_lower for k in report_keywords):
        actions.append({"id": "generate_pdf", "label": "📄 Generate Complaint PDF"})
        
    # Check if severity is high/critical and support helpline is relevant
    severity = threat_context.get("severity", "safe").lower()
    support_keywords = ["someone", "talk", "help", "helpline", "support", "scared", "afraid", "panic", "expose"]
    if severity in ["critical", "high"] or any(k in user_lower or k in ai_lower for k in support_keywords):
        if not any(a["id"] == "support" for a in actions):
            actions.append({"id": "support", "label": "🤝 Talk to someone"})

    # Ensure a basic set of actions if none were triggered
    if len(actions) < 2:
        if not any(a["id"] == "next_steps" for a in actions):
            actions.append({"id": "next_steps", "label": "📋 Show next steps"})
        if not any(a["id"] == "save_evidence" for a in actions):
            actions.append({"id": "save_evidence", "label": "💾 Save to Evidence Vault"})
            
    # Remove duplicates while preserving order
    seen = set()
    unique_actions = []
    for a in actions:
        if a["id"] not in seen:
            seen.add(a["id"])
            unique_actions.append(a)
            
    return unique_actions[:4]

# ---------------------------------------------------------
# ROUTE 1: INITIAL ANALYSIS
# ---------------------------------------------------------
@app.route('/api/chat/analyze', methods=['POST'])
def chat_analyze():
    data = request.get_json()
    if not data:
        return jsonify({"error": "Missing request payload"}), 400
        
    text = data.get('text', '')
    platform = data.get('platform', 'Webpage')
    context = data.get('context', '')
    session_id = data.get('session_id')
    
    if not text:
        return jsonify({"error": "Missing 'text' parameter"}), 400
        
    # Generate new session ID if none exists
    if not session_id:
        session_id = str(uuid.uuid4())
        
    # Check if this session already exists in the SQLite DB
    existing_session = get_session(session_id)
    if existing_session:
        last_message_content = existing_session.get("history", [{}])[-1].get("content", "")
        actions = generate_followup_actions("", last_message_content, {
            "threat_type": existing_session.get("threat_type", "none"),
            "severity":    existing_session.get("severity", "safe"),
            "summary":     existing_session.get("summary", ""),
            "platform":    platform,
            "indicators":  []
        })
        
        return jsonify({
            "session_id": session_id,
            "opening_message": existing_session.get("history", [{}])[1].get("content") if len(existing_session.get("history", [])) > 1 else "",
            "threat_data": {
                "threat_type": existing_session.get("threat_type", "none"),
                "severity":    existing_session.get("severity", "safe"),
                "summary":     existing_session.get("summary", ""),
                "platform":    platform,
                "indicators":  []
            },
            "history": existing_session.get("history", []),
            "actions": actions
        }), 200

    analysis = analyze_with_gemini(text, platform, context)
    threat_type = analysis.get("type", "none")
    severity    = analysis.get("severity", "safe")
    summary     = analysis.get("summary", "No threat detected.")
    indicators  = analysis.get("indicators", [])
    ai_opening  = analysis.get("opening_message", "")
    ai_actions  = analysis.get("actions", [])

    # Select pre-written template based on threat type
    templates = {
        "sextortion": (
            "⚠️ **I've analyzed this and it shows signs of sextortion (sexual extortion).**\n\n"
            "**Don't panic.** This is a common coercion tactic and you are not to blame. "
            "Please follow these immediate steps:\n"
            "- **Do not send money or more images.** Harassers rarely stop even if you pay.\n"
            "- **Stop communication.** Block them immediately on this platform.\n"
            "- **Preserve evidence.** Take screenshots of their profile, user ID, and messages now."
        ),
        "grooming": (
            "⚠️ **I've analyzed this conversation and it shows signs of online grooming.**\n\n"
            "This person may be trying to build a false sense of trust to exploit you. "
            "Here is what you should do:\n"
            "- **Do not share any personal details** (address, school, phone number, or private photos).\n"
            "- **Keep your distance.** Stop responding to demanding or overly personal questions.\n"
            "- **Talk to a trusted adult or counselor** about this interaction immediately."
        ),
        "bullying": (
            "⚠️ **I've analyzed this and it shows signs of online bullying.**\n\n"
            "You do not have to tolerate this treatment. "
            "Here is how to handle it:\n"
            "- **Do not engage or reply in anger.** Harassers want a reaction.\n"
            "- **Block the account** immediately.\n"
            "- **Report their messages** to the platform support team."
        ),
        "harassment": (
            "⚠️ **I've analyzed this and it looks like online harassment.**\n\n"
            "Repeated unwanted contact is a safety violation. "
            "Please take these precautions:\n"
            "- **Document the behavior.** Take clear screenshots of the messages.\n"
            "- **Block and report** the user on the platform.\n"
            "- **Adjust your privacy settings** to restrict who can message you."
        ),
        "blackmail": (
            "⚠️ **I've analyzed this and it shows signs of blackmail or coercion.**\n\n"
            "They are attempting to control you through fear. "
            "Remember:\n"
            "- **Do not comply with demands.** Giving in often leads to further demands.\n"
            "- **Collect proof.** Screenshot everything including their username/profile link.\n"
            "- **Report to law enforcement** or a cybercrime portal."
        ),
        "manipulation": (
            "⚠️ **I've analyzed this and it appears to involve manipulation or pressure.**\n\n"
            "They may be trying to guilt or coerce you into doing something you are uncomfortable with. "
            "Please take care:\n"
            "- **Trust your instincts.** If something feels wrong, it is wrong.\n"
            "- **You have the right to say no** and end the conversation immediately.\n"
            "- **Take a break** and discuss this with someone you trust."
        ),
        "none": (
            "👋 **Hi! I've analyzed the text, and I didn't detect any immediate digital safety threats.**\n\n"
            "However, if you feel uncomfortable or unsafe, your feelings are valid. "
            "How can I help you support your digital safety today?"
        )
    }
    
    # Use Gemini's opening_message if provided, else fall back to local template
    if ai_opening:
        opening_message = ai_opening
    else:
        opening_message = templates.get(threat_type, templates["none"])

    # Use Gemini's action list if returned, else build one based on severity
    if ai_actions:
        actions = ai_actions
    else:
        actions = [
            {"id": "explain",       "label": "📊 Explain why this is dangerous"},
            {"id": "save_evidence", "label": "💾 Save to Evidence Vault"},
            {"id": "next_steps",    "label": "📋 Show next steps"}
        ]
        # Add talk-to-someone for high/critical severity
        if severity in ["critical", "high"]:
            actions.append({"id": "support", "label": "🤝 Talk to someone"})
        # Remove save_evidence for safe/low severity — nothing to preserve
        if severity in ["safe", "low"]:
            actions = [a for a in actions if a["id"] != "save_evidence"]

    # Save opening turn to session history in DB
    history = [
        {"role": "user",      "content": f"[System Context: User highlighted text '{text}' on platform '{platform}']"},
        {"role": "assistant", "content": opening_message}
    ]
    save_session(session_id, threat_type, severity, summary, history)

    return jsonify({
        "session_id": session_id,
        "opening_message": opening_message,
        "threat_data": {
            "threat_type": threat_type,
            "severity":    severity,
            "summary":     summary,
            "platform":    platform,
            "indicators":  indicators
        },
        "actions": actions
    }), 200

# ---------------------------------------------------------
# ROUTE 2: GENERAL GREETING (No text selected – floating button)
# ---------------------------------------------------------
@app.route('/api/chat/greeting', methods=['POST'])
def chat_greeting():
    """
    Called when the user opens SafeGuide WITHOUT any highlighted text.
    Returns a warm, welcoming greeting and stores the session in SQLite.
    """
    data = request.get_json(silent=True) or {}
    session_id = data.get('session_id') or str(uuid.uuid4())

    # Check if a general session already exists (re-entry)
    existing = get_session(session_id)
    if existing:
        last_message_content = existing.get("history", [{}])[-1].get("content", "")
        actions = generate_followup_actions("", last_message_content, {
            "threat_type": existing.get("threat_type", "none"),
            "severity":    existing.get("severity", "safe"),
            "summary":     existing.get("summary", ""),
            "platform":    "General",
            "indicators":  []
        })
        return jsonify({
            "session_id": session_id,
            "greeting":   existing.get("history", [{}])[-1].get("content", "") if len(existing.get("history", [])) > 1 else "",
            "threat_data": {
                "threat_type": "none",
                "severity":    "safe",
                "summary":     "",
                "platform":    "General",
                "indicators":  []
            },
            "history": existing.get("history", []),
            "actions": actions
        }), 200

    greeting_message = (
        "👋 **Hello! I'm SafeGuide AI — your personal digital safety companion.**\n\n"
        "I'm here to help you with:\n"
        "- 🔍 **Analyzing suspicious messages** — paste or highlight any text and I'll check it for threats like harassment, grooming, or sextortion.\n"
        "- 🖼️ **Verifying screenshots** — I can detect if images have been edited or fabricated.\n"
        "- 📋 **Understanding your options** — from blocking and reporting to filing a cyber complaint.\n"
        "- 🤝 **Finding support** — connecting you with helplines and resources.\n\n"
        "**How can I help you stay safe today?**"
    )

    greeting_actions = [
        {"id": "safety_query",     "label": "📖 Online safety tips"},
        {"id": "verify_screenshot","label": "🖼️ Upload a screenshot"},
        {"id": "next_steps",       "label": "📋 What are my options?"},
        {"id": "support",          "label": "🤝 Talk to someone"}
    ]

    # Store the greeting turn in SQLite so it persists across re-opens
    history = [
        {"role": "user",      "content": "[System: User opened SafeGuide without highlighted text]"},
        {"role": "assistant", "content": greeting_message}
    ]
    save_session(session_id, "none", "safe", "General safety session", history)

    return jsonify({
        "session_id": session_id,
        "greeting":   greeting_message,
        "threat_data": {
            "threat_type": "none",
            "severity":    "safe",
            "summary":     "",
            "platform":    "General",
            "indicators":  []
        },
        "actions": greeting_actions
    }), 200

# ---------------------------------------------------------
# ROUTE 3: FOLLOW-UP CONVERSATION
# ---------------------------------------------------------
@app.route('/api/chat/message', methods=['POST'])
def chat_message():
    data = request.get_json()
    if not data:
        return jsonify({"error": "Missing request payload"}), 400
        
    session_id = data.get('session_id')
    user_message = data.get('message', '')
    threat_context = data.get('threat_context', {})
    
    if not session_id or not user_message:
        return jsonify({"error": "Missing session_id or message parameter"}), 400
        
    # Retrieve session history from DB
    session_data = get_session(session_id)
    if session_data:
        history = session_data['history']
        threat_type = session_data['threat_type']
        severity = session_data['severity']
        summary = session_data['summary']
    else:
        # Fallback if session database record is missing
        history = []
        threat_type = threat_context.get('threat_type', 'none')
        severity = threat_context.get('severity', 'safe')
        summary = threat_context.get('summary', '')
        
    # Append user's new message to the history
    history.append({"role": "user", "content": user_message})
    
    # Call Gemini to generate a response
    reply = gemini_chat(history, user_message, threat_context)
    
    # Append AI response and save back to SQLite
    history.append({"role": "assistant", "content": reply})
    save_session(session_id, threat_type, severity, summary, history)
    
    # Suggest follow-up action buttons dynamically based on dialogue context
    actions = generate_followup_actions(user_message, reply, threat_context)
    
    return jsonify({
        "reply": reply,
        "actions": actions
    }), 200

# ---------------------------------------------------------
# ROUTE 3: IMAGE AUTHENTICITY VERIFICATION
# ---------------------------------------------------------
@app.route('/api/image/verify', methods=['POST'])
def image_verify():
    data = request.get_json()
    if not data:
        return jsonify({"error": "Missing request payload"}), 400

    image_data = data.get('image_data', '')   # base64-encoded string
    mime_type  = data.get('mime_type', 'image/png')

    if not image_data:
        return jsonify({"error": "Missing image_data parameter"}), 400

    if not GEMINI_API_KEY:
        return jsonify({"error": "No Gemini API key configured."}), 500

    forensic_prompt = """You are SafeGuide AI, a digital forensics expert specializing in image authenticity verification. Your ONLY purpose is to analyze images for signs of manipulation, AI generation, or fabrication.

CRITICAL RULES:
1. You are NOT a general chatbot. You ONLY analyze images for authenticity.
2. You do NOT give legal advice. You provide forensic observations.
3. You ALWAYS explain your reasoning in plain, non-technical language.
4. You NEVER claim 100% certainty. Always express confidence levels.

FORENSIC CHECKS YOU PERFORM:
1. Error Level Analysis (ELA): Detects regions with different compression levels (indicates pasting, cloning, or editing).
2. Metadata Analysis: Checks for missing camera info, stripped timestamps, Photoshop traces, or editing software signatures.
3. Deepfake/AI Detection: Looks for unnatural textures, lighting inconsistencies, asymmetrical features, and AI generation artifacts.
4. Noise Consistency: Detects different noise levels across regions (indicates image stitching from multiple sources).

VERDICT DEFINITIONS:
- "AUTHENTIC": No significant signs of manipulation detected. Confidence is moderate to high.
- "SUSPICIOUS": Some inconsistencies found. Recommend manual verification against original source.
- "FABRICATED": Strong evidence of manipulation, editing, or AI generation. Do not trust as evidence.

OUTPUT FORMAT:
Return ONLY valid JSON. No markdown. No extra text.
{
  "verdict": "SUSPICIOUS",
  "confidence": "72%",
  "checks": {
    "ela": "Description of compression analysis findings.",
    "metadata": "Description of metadata findings.",
    "deepfake": "Description of deepfake/AI detection findings.",
    "noise": "Description of noise consistency findings."
  },
  "summary": "One sentence plain-language forensic summary.",
  "indicators": ["list", "of", "red", "flags", "found"]
}

Analyze the provided image now and return ONLY the JSON."""

    try:
        import base64
        model = genai.GenerativeModel("gemini-2.5-flash")

        # Decode base64 and pass as inline image part
        image_bytes = base64.b64decode(image_data)
        image_part  = {"mime_type": mime_type, "data": image_bytes}

        response = model.generate_content(
            [forensic_prompt, image_part],
            generation_config={"response_mime_type": "application/json"}
        )

        result = json.loads(response.text.strip())

        # Normalize verdict to uppercase
        result["verdict"] = result.get("verdict", "SUSPICIOUS").upper()
        result.setdefault("confidence", "N/A")
        result.setdefault("checks", {})
        result.setdefault("summary", "Analysis complete.")
        result.setdefault("indicators", [])

        return jsonify(result), 200

    except Exception as e:
        print(f"Image verify exception: {e}")
        return jsonify({
            "verdict": "SUSPICIOUS",
            "confidence": "Unknown",
            "checks": {
                "ela":      "Could not perform analysis.",
                "metadata": "Could not perform analysis.",
                "deepfake": "Could not perform analysis.",
                "noise":    "Could not perform analysis."
            },
            "summary": "Image analysis failed. Please try again or inspect the image manually.",
            "indicators": []
        }), 200

# ---------------------------------------------------------
# ROUTE 4: IMAGE VERIFY FOLLOW-UP MESSAGE
# ---------------------------------------------------------
@app.route('/api/image/followup', methods=['POST'])
def image_followup():
    data = request.get_json()
    if not data:
        return jsonify({"error": "Missing request payload"}), 400

    verdict        = data.get('verdict', 'SUSPICIOUS').upper()
    confidence     = data.get('confidence', 'N/A')
    summary        = data.get('summary', '')
    threat_type    = data.get('threat_type', 'none')
    severity       = data.get('severity', 'safe')
    threat_summary = data.get('threat_summary', '')

    if not GEMINI_API_KEY:
        return jsonify({"reply": "Image analysis complete. Please review the forensic results above."}), 200

    prompt = f"""You are SafeGuide AI. You have just completed an image authenticity analysis for the user.

CONTEXT:
- The user uploaded an image for verification.
- The verdict was: {verdict}
- The confidence was: {confidence}
- The forensic summary was: {summary}
- Broader threat context — Type: {threat_type}, Severity: {severity}, Summary: {threat_summary}

YOUR TASK:
Generate a single, clear follow-up message that references this image verification result and connects it to the broader threat.

RULES:
1. If verdict is "FABRICATED": Advise the user not to trust the image as evidence. Suggest capturing proof directly from the original source (e.g., taking their own screenshot from the original conversation thread). Warn that fabricated evidence can undermine their case.
2. If verdict is "SUSPICIOUS": Advise caution. Suggest manually cross-checking this image against the original conversation. Recommend keeping it for reference but gathering additional proof.
3. If verdict is "AUTHENTIC": Acknowledge the image appears genuine. Guide the user to save it to the Evidence Vault immediately and use it as part of their complaint or report.
4. ALWAYS connect the image result to the broader threat context if available.
5. ALWAYS offer 1-2 clear, actionable next steps the user can take right now.
6. Keep the tone compassionate, calm, and brief (3-5 sentences max).
7. Use plain text. No markdown. No code blocks.

OUTPUT: Just your response text. Natural conversational tone."""

    try:
        model = genai.GenerativeModel("gemini-2.5-flash")
        response = model.generate_content(prompt)
        return jsonify({"reply": response.text.strip()}), 200
    except Exception as e:
        print(f"Image followup exception: {e}")
        # Deterministic fallback based on verdict
        fallbacks = {
            "FABRICATED": (
                "This image shows strong signs of manipulation — I would not rely on it as evidence. "
                "Instead, try to capture a fresh screenshot directly from the original conversation thread on "
                f"the platform. That will be far more reliable for your {threat_type} case."
            ),
            "SUSPICIOUS": (
                "The image has some inconsistencies I can't fully explain. I'd recommend cross-checking it "
                "against the original conversation before using it as evidence. Keep it for now, but try to "
                "gather additional screenshots directly from the source."
            ),
            "AUTHENTIC": (
                "The image appears authentic — good news. I recommend saving it to your Evidence Vault right "
                "now so it is securely stored. You can then include it in your complaint report or hand it to "
                "a trusted adult or authority."
            )
        }
        return jsonify({"reply": fallbacks.get(verdict, fallbacks["SUSPICIOUS"])}), 200

# ---------------------------------------------------------
# ROUTE: PIL / ELA IMAGE AUTHENTICITY VERIFICATION
# POST /api/ela/verify
# Accepts base64-encoded image, runs Error Level Analysis
# (ELA) with Pillow, checks metadata, returns verdict.
# ---------------------------------------------------------

def _ela_score(img_bytes):
    """
    Run Error Level Analysis on raw image bytes.
    Returns (avg_error_score 0-100, human-readable description).
    """
    if not PIL_AVAILABLE:
        return 0.0, "Pillow not installed — ELA unavailable."
    original    = Image.open(io.BytesIO(img_bytes)).convert("RGB")
    buf         = io.BytesIO()
    original.save(buf, format="JPEG", quality=90)
    buf.seek(0)
    recompressed = Image.open(buf).convert("RGB")
    diff    = ImageChops.difference(original, recompressed)
    pixels  = list(diff.getdata())
    total   = sum(sum(ch for ch in px) for px in pixels)
    avg     = total / (len(pixels) * 3)
    score   = min(100.0, round(avg / 255.0 * 100 * 8, 2))
    if score > 30:
        desc = (f"High ELA score ({score:.1f}/100) — significant compression "
                "anomalies detected, indicating possible manipulation.")
    elif score > 15:
        desc = (f"Moderate ELA score ({score:.1f}/100) — minor inconsistencies "
                "present; image may have been lightly edited.")
    else:
        desc = (f"Low ELA score ({score:.1f}/100) — compression patterns appear "
                "uniform; no obvious manipulation detected.")
    return score, desc


def _metadata_issues(img_bytes):
    """Inspect EXIF / info metadata for suspicious signals."""
    if not PIL_AVAILABLE:
        return []
    issues = []
    try:
        img  = Image.open(io.BytesIO(img_bytes))
        info = img.info or {}
        if info.get("exif") is None:
            issues.append("No EXIF metadata — may have been stripped by an editor.")
        software = info.get("Software") or info.get("software")
        if software:
            issues.append(f"Software tag: '{software}' — processed by this tool.")
        comment = info.get("comment") or info.get("Comment")
        if comment:
            issues.append(f"Comment field found: '{str(comment)[:80]}'.")
        if not issues:
            issues.append("Metadata appears clean — no editing signatures detected.")
    except Exception as e:
        issues.append(f"Metadata extraction failed: {str(e)}")
    return issues


@app.route('/api/ela/verify', methods=['POST'])
def verify_image_ela():
    """
    ELA-based image authenticity verification.
    Input  JSON: { image_data: <base64>, mime_type: <str>, session_id: <str|null> }
    Output JSON: { verdict, confidence, confidence_pct, summary, details, indicators }
    """
    data = request.get_json(silent=True)
    if not data or not data.get('image_data'):
        return jsonify({"error": "Missing image_data in request body."}), 400

    if not PIL_AVAILABLE:
        return jsonify({
            "verdict":        "SUSPICIOUS",
            "confidence":     0.5,
            "confidence_pct": "50%",
            "summary":        "Pillow is not installed. Run: pip install Pillow",
            "details":        {"ela": "Unavailable", "metadata": "Unavailable"},
            "indicators":     ["Pillow library missing"]
        }), 200

    try:
        img_bytes = base64.b64decode(data['image_data'])
    except Exception:
        return jsonify({"error": "Invalid base64 image data."}), 400

    ela_score, ela_desc = _ela_score(img_bytes)
    meta_issues         = _metadata_issues(img_bytes)

    if ela_score > 30:
        verdict    = "FABRICATED"
        confidence = min(0.95, 0.60 + ela_score / 200)
        summary    = (
            "This image shows strong signs of manipulation. ELA detected significant "
            "compression inconsistencies typical of copy-paste editing or content insertion. "
            "Do not rely on this as primary evidence without independent verification."
        )
        indicators = ["High ELA error score", "Compression inconsistencies detected"]
    elif ela_score > 15:
        verdict    = "SUSPICIOUS"
        confidence = 0.45 + ela_score / 150
        summary    = (
            "This image has moderate anomalies — it may have been lightly edited or "
            "resaved multiple times. Cross-check against the original source before "
            "using it as evidence."
        )
        indicators = ["Moderate ELA anomalies", "Possible light editing or multiple resaves"]
    else:
        verdict    = "AUTHENTIC"
        confidence = max(0.70, 1.0 - ela_score / 100)
        summary    = (
            "This image appears authentic. ELA did not detect significant manipulation "
            "artefacts. Save it to your Evidence Vault immediately to preserve it for "
            "any complaint or report."
        )
        indicators = ["Uniform compression pattern", "No manipulation artefacts detected"]

    for issue in meta_issues:
        if "clean" not in issue.lower() and issue not in indicators:
            indicators.append(issue)

    confidence_pct = f"{round(confidence * 100)}%"
    result = {
        "verdict":        verdict,
        "confidence":     round(confidence, 3),
        "confidence_pct": confidence_pct,
        "summary":        summary,
        "details": {
            "ela":       ela_desc,
            "ela_score": ela_score,
            "metadata":  " | ".join(meta_issues) if meta_issues else "No metadata issues.",
        },
        "indicators": indicators,
    }

    session_id = data.get('session_id')
    if session_id:
        try:
            sess = get_session(session_id)
            if sess:
                history = sess.get('history', [])
                history.append({
                    "role":    "assistant",
                    "content": (f"[Image Verification] Verdict: {verdict} "
                                f"({confidence_pct}) — {summary}")
                })
                save_session(session_id, sess.get('threat_type','none'),
                             sess.get('severity','safe'), sess.get('summary',''), history)
        except Exception as e:
            print(f"Session update after ELA verify failed: {e}")

    return jsonify(result), 200

# =====================================================================

if __name__ == '__main__':
    print(f"SafeSphere backend server running locally on http://127.0.0.1:{PORT}")
    app.run(host='0.0.0.0', port=PORT, debug=True)
