// ============================================================
// SafeGuide Chat — chat.js
// Handles: URL param detection, both scenarios (text selected
// vs greeting), API calls, image upload + ELA verification,
// conversation memory, and all UI updates.
// ============================================================

'use strict';

const BACKEND = 'http://127.0.0.1:8081';

// ── State ────────────────────────────────────────────────────
let sessionId       = null;   // UUID assigned by backend
let threatContext   = null;   // threat_data object from /analyze
let isWaiting       = false;  // prevent double-sends

// ── DOM refs ─────────────────────────────────────────────────
const loadingState      = document.getElementById('loading-state');
const messagesList      = document.getElementById('messages-list');
const threatBanner      = document.getElementById('threat-banner');
const threatIcon        = document.getElementById('threat-icon');
const threatSeverityEl  = document.getElementById('threat-severity');
const threatSummaryEl   = document.getElementById('threat-summary');
const actionsArea       = document.getElementById('actions-area');
const buttonsGrid       = document.getElementById('buttons-grid');
const chatInput         = document.getElementById('chat-input');
const sendBtn           = document.getElementById('send-btn');
const uploadImgBtn      = document.getElementById('upload-img-btn');
const platformBadge     = document.getElementById('platform-badge');
const chatBody          = document.getElementById('chat-body');
const statusDot         = document.getElementById('status-dot');

// Image verify panel
const imageVerifyPanel  = document.getElementById('image-verify-panel');
const verifyClose       = document.getElementById('verify-close');
const dropZone          = document.getElementById('drop-zone');
const imageInput        = document.getElementById('image-input');
const imagePreview      = document.getElementById('image-preview');
const verifyBtn         = document.getElementById('verify-btn');

let selectedImageBase64 = null;
let selectedImageMime   = 'image/png';

// ============================================================
// INIT — runs when the page loads
// ============================================================
document.addEventListener('DOMContentLoaded', () => {
  const params   = new URLSearchParams(window.location.search);
  const text     = params.get('text')     || '';
  const platform = params.get('platform') || 'Webpage';
  const context  = params.get('context')  || '';

  // Update header badge with detected platform
  if (platformBadge) platformBadge.textContent = platform;

  // Wire up input events
  chatInput.addEventListener('input',   handleInputResize);
  chatInput.addEventListener('keydown', handleKeyDown);
  sendBtn.addEventListener('click',     handleSend);

  // Upload button opens image verify panel
  uploadImgBtn.addEventListener('click', showVerifyPanel);

  // Verify panel events
  verifyClose.addEventListener('click',  hideVerifyPanel);
  imageInput.addEventListener('change',  e => {
    if (e.target.files[0]) loadImageFile(e.target.files[0]);
  });
  verifyBtn.addEventListener('click', runImageVerification);

  // Drag-and-drop on drop zone
  dropZone.addEventListener('dragover', e => {
    e.preventDefault();
    dropZone.classList.add('dragging');
  });
  dropZone.addEventListener('dragleave', () => dropZone.classList.remove('dragging'));
  dropZone.addEventListener('drop', e => {
    e.preventDefault();
    dropZone.classList.remove('dragging');
    const file = e.dataTransfer.files[0];
    if (file && file.type.startsWith('image/')) loadImageFile(file);
  });

  // Check backend connectivity
  pingBackend();

  // Scenario A: text selected → analyze it
  // Scenario B: no text      → load greeting
  if (text) {
    performInitialAnalysis(text, platform, context);
  } else {
    loadGreeting();
  }
});

// ── Ping backend and update status dot ──────────────────────
async function pingBackend() {
  try {
    const r = await fetch(`${BACKEND}/`, { method: 'GET' });
    if (r.ok) {
      statusDot.style.background  = '#3fb950';
      statusDot.title = 'Backend connected';
    } else throw new Error();
  } catch {
    statusDot.style.background  = '#f85149';
    statusDot.style.boxShadow   = '0 0 6px rgba(248,81,73,0.7)';
    statusDot.title = 'Backend offline — start app.py';
  }
}

// ── Auto-resize textarea ─────────────────────────────────────
function handleInputResize() {
  chatInput.style.height = 'auto';
  chatInput.style.height = Math.min(chatInput.scrollHeight, 100) + 'px';
  sendBtn.disabled = !chatInput.value.trim() || isWaiting;
}

// ── Enter to send, Shift+Enter for newline ───────────────────
function handleKeyDown(e) {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    handleSend();
  }
}

// ============================================================
// SCENARIO A — Initial threat analysis (text was selected)
// POST /api/chat/analyze
// ============================================================
async function performInitialAnalysis(text, platform, context) {
  showLoading(true);
  try {
    const res = await fetch(`${BACKEND}/api/chat/analyze`, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ text, platform, context, session_id: null }),
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || `Server error ${res.status}`);
    }

    const data = await res.json();
    sessionId     = data.session_id;
    threatContext = data.threat_data;

    showLoading(false);
    setupThreatBanner(data.threat_data);

    // Show full history if returning to an existing session,
    // otherwise show just the opening message
    if (data.history && data.history.length > 1) {
      messagesList.innerHTML = '';
      for (let i = 1; i < data.history.length; i++) {
        const m = data.history[i];
        appendMessage(m.content, m.role === 'user' ? 'user' : 'assistant', false);
      }
    } else {
      appendMessage(data.opening_message, 'assistant');
    }

    setupActionButtons(data.actions);
    enableInput();

  } catch (err) {
    showLoading(false);
    showError(`Could not reach SafeGuide: ${err.message}. Make sure app.py is running on port 8081.`);
  }
}

// ============================================================
// SCENARIO B — Greeting (no text selected)
// POST /api/chat/greeting
// ============================================================
async function loadGreeting() {
  showLoading(true);
  try {
    // Persist a general session ID in localStorage so re-opens continue the conversation
    let generalId = localStorage.getItem('sg_general_session_id');
    if (!generalId) {
      generalId = 'general-' + Date.now() + '-' + Math.random().toString(36).slice(2, 9);
      localStorage.setItem('sg_general_session_id', generalId);
    }

    const res = await fetch(`${BACKEND}/api/chat/greeting`, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ session_id: generalId }),
    });

    if (!res.ok) throw new Error(`Server error ${res.status}`);

    const data = await res.json();
    sessionId     = data.session_id;
    threatContext = data.threat_data;

    showLoading(false);
    threatBanner.style.display = 'none'; // no threat in greeting mode

    if (data.history && data.history.length > 1) {
      messagesList.innerHTML = '';
      for (let i = 1; i < data.history.length; i++) {
        const m = data.history[i];
        appendMessage(m.content, m.role === 'user' ? 'user' : 'assistant', false);
      }
    } else {
      appendMessage(data.greeting, 'assistant');
    }

    setupActionButtons(data.actions);
    enableInput();

  } catch (err) {
    // Graceful fallback — hardcoded greeting so the UI is never blank
    showLoading(false);
    threatBanner.style.display = 'none';
    appendMessage(
      "👋 **Hello! I'm SafeGuide AI — your digital safety companion.**\n\n" +
      "I can help you with:\n" +
      "- 🔍 Analyzing suspicious messages for threats\n" +
      "- 🖼️ Verifying if screenshots have been tampered with\n" +
      "- 📋 Understanding your options and next steps\n" +
      "- 🤝 Finding support and helplines\n\n" +
      "**How can I help you stay safe today?**",
      'assistant'
    );
    setupActionButtons([
      { id: 'paste_message',     label: '📋 Paste a suspicious message' },
      { id: 'verify_screenshot', label: '🖼️ Upload a screenshot'         },
      { id: 'safety_tips',       label: '🔒 Online safety tips'           },
      { id: 'support',           label: '🤝 Talk to someone'              },
    ]);
    enableInput();
  }
}

// ============================================================
// FOLLOW-UP MESSAGE
// POST /api/chat/message
// ============================================================
async function sendMessage(text) {
  if (isWaiting || !text.trim()) return;
  isWaiting = true;
  chatInput.disabled = true;
  sendBtn.disabled   = true;

  appendMessage(text, 'user');
  const typingEl = appendTypingIndicator();
  scrollToBottom();

  try {
    const res = await fetch(`${BACKEND}/api/chat/message`, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({
        session_id:     sessionId,
        message:        text,
        threat_context: threatContext,
      }),
    });

    typingEl.remove();

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || `Server error ${res.status}`);
    }

    const data = await res.json();
    appendMessage(data.reply, 'assistant');
    if (data.actions) setupActionButtons(data.actions);

  } catch (err) {
    typingEl.remove();
    appendMessage(`⚠️ ${err.message}. Please check that the SafeSphere server is running.`, 'assistant');
  } finally {
    isWaiting      = false;
    chatInput.disabled = false;
    sendBtn.disabled   = !chatInput.value.trim();
    chatInput.focus();
    scrollToBottom();
  }
}

// ── Send handler ─────────────────────────────────────────────
function handleSend() {
  const text = chatInput.value.trim();
  if (!text || isWaiting) return;
  chatInput.value      = '';
  chatInput.style.height = 'auto';
  sendBtn.disabled     = true;
  sendMessage(text);
}

// ============================================================
// ACTION BUTTON HANDLING
// ============================================================
function setupActionButtons(actions) {
  buttonsGrid.innerHTML = '';
  if (!actions || actions.length === 0) {
    actionsArea.style.display = 'none';
    return;
  }
  actions.forEach(action => {
    const btn = document.createElement('button');
    btn.className   = 'action-btn';
    btn.textContent = action.label || action.text || action.id;
    btn.addEventListener('click', () => handleActionClick(action.id, action.label || action.text));
    buttonsGrid.appendChild(btn);
  });
  actionsArea.style.display = 'block';
}

// ... handleActionClick remains exactly the same ...
function handleActionClick(id, label) {
  // Special case: open image verify panel
  if (id === 'verify_screenshot') {
    actionsArea.style.display = 'none';
    showVerifyPanel();
    return;
  }

  // Map action IDs to natural-language prompts
  const prompts = {
    explain:       'Can you explain why this message is dangerous?',
    save_evidence: 'How do I save this evidence to the Evidence Vault?',
    next_steps:    'What are my next steps right now?',
    support:       'Who can I talk to for support?',
    generate_pdf:  'How do I generate a complaint PDF for this incident?',
    safety_tips:   'What are the best practices for staying safe online?',
    paste_message: 'I want to paste a suspicious message for analysis.',
  };

  const text = prompts[id] || label || id;
  actionsArea.style.display = 'none';
  sendMessage(text);
}

// ============================================================
// THREAT BANNER
// ============================================================
function setupThreatBanner(threatData) {
  if (!threatData || threatData.threat_type === 'none' || threatData.severity === 'safe') {
    threatBanner.className = 'sg-threat-banner safe';
    threatIcon.textContent = '✅';
    threatSeverityEl.textContent = 'SAFE';
    threatSeverityEl.className   = 'sg-threat-value safe';
    threatSummaryEl.textContent  = 'No immediate threats detected in this text.';
  } else {
    const sev  = (threatData.severity || 'low').toLowerCase();
    const type = (threatData.threat_type || 'unknown').toUpperCase();

    const icons = { critical: '🚨', high: '⚠️', moderate: '🔶', low: '🔵', safe: '✅' };
    threatBanner.className       = `sg-threat-banner ${sev}`;
    threatIcon.textContent       = icons[sev] || '⚠️';
    threatSeverityEl.textContent = `${sev.toUpperCase()} · ${type}`;
    threatSeverityEl.className   = `sg-threat-value ${sev}`;
    threatSummaryEl.textContent  = threatData.summary || '';
  }
  threatBanner.style.display = 'flex';
  threatBanner.style.flexDirection = 'column';
}

// ============================================================
// IMAGE VERIFY PANEL
// ============================================================
function showVerifyPanel() {
  // Reset state
  selectedImageBase64    = null;
  imagePreview.style.display = 'none';
  imagePreview.src       = '';
  verifyBtn.disabled     = true;
  verifyBtn.textContent  = 'Analyze Screenshot';
  verifyBtn.classList.remove('loading');
  imageInput.value       = '';
  imageVerifyPanel.style.display = 'flex';
}

// ... verify image logic ...
function hideVerifyPanel() {
  imageVerifyPanel.style.display = 'none';
}

function loadImageFile(file) {
  selectedImageMime = file.type || 'image/png';
  const reader = new FileReader();
  reader.onload = ev => {
    imagePreview.src           = ev.target.result;
    imagePreview.style.display = 'block';
    selectedImageBase64        = ev.target.result.split(',')[1];
    verifyBtn.disabled         = false;
  };
  reader.readAsDataURL(file);
}

// ── Run ELA image verification ──────────────────────────────
async function runImageVerification() {
  if (!selectedImageBase64) return;

  verifyBtn.disabled    = true;
  verifyBtn.textContent = 'Analyzing…';
  verifyBtn.classList.add('loading');

  try {
    const res = await fetch(`${BACKEND}/api/ela/verify`, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({
        image_data: selectedImageBase64,
        mime_type:  selectedImageMime,
        session_id: sessionId,
      }),
    });

    if (!res.ok) throw new Error(`Server error ${res.status}`);
    const result = await res.json();

    hideVerifyPanel();
    appendForensicCard(result);
    fetchImageFollowup(result);

  } catch (err) {
    hideVerifyPanel();
    appendMessage(`Sorry, image verification failed: ${err.message}`, 'assistant');
  } finally {
    verifyBtn.classList.remove('loading');
  }
}

// ── Render the forensic result card ─────────────────────────
function appendForensicCard(result) {
  const verdict    = (result.verdict    || 'SUSPICIOUS').toUpperCase();
  const confidence = result.confidence  != null
    ? `${Math.round(result.confidence * 100)}%`
    : (result.confidence_pct || 'N/A');
  const summary    = result.summary  || '';
  const checks     = result.details  || result.checks || {};
  const indicators = result.indicators || [];

  const checkLabels = { ela: 'ELA Score', metadata: 'Metadata', deepfake: 'AI/Deepfake', noise: 'Noise' };
  const checksHtml = Object.entries(checkLabels)
    .filter(([k]) => checks[k])
    .map(([k, label]) =>
      `<div class="forensic-check-row">
         <span class="check-label">${label}</span>
         <span class="check-value">${checks[k]}</span>
       </div>`)
    .join('');

  const pillsHtml = indicators
    .map(i => `<span class="indicator-pill">${i}</span>`)
    .join('');

  const wrapper = document.createElement('div');
  wrapper.className = 'message-wrapper assistant';
  wrapper.innerHTML = `
    <div class="message-bubble" style="padding:0;background:transparent;border:none;">
      <div class="forensic-card">
        <div class="forensic-verdict-row">
          <span class="verdict-badge ${verdict}">${verdict}</span>
          <span class="verdict-confidence">Confidence: ${confidence}</span>
        </div>
        <p class="forensic-summary">${escapeHtml(summary)}</p>
        ${checksHtml ? `<div class="forensic-checks">${checksHtml}</div>` : ''}
        ${pillsHtml  ? `<div class="forensic-indicators">${pillsHtml}</div>` : ''}
      </div>
    </div>
    <span class="message-time">${timeNow()}</span>`;

  messagesList.appendChild(wrapper);
  scrollToBottom();
}

// ── Fetch SafeGuide's follow-up after image verification ────
async function fetchImageFollowup(result) {
  const typingEl = appendTypingIndicator();
  scrollToBottom();

  try {
    const res = await fetch(`${BACKEND}/api/image/followup`, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({
        verdict:        result.verdict        || 'SUSPICIOUS',
        confidence:     result.confidence_pct || result.confidence || 'N/A',
        summary:        result.summary        || '',
        threat_type:    threatContext?.threat_type || 'none',
        severity:       threatContext?.severity    || 'safe',
        threat_summary: threatContext?.summary     || '',
      }),
    });

    typingEl.remove();
    if (!res.ok) throw new Error();
    const data = await res.json();
    appendMessage(data.reply || 'Analysis complete. Review the forensic results above.', 'assistant');

  } catch {
    typingEl.remove();
    const fallbacks = {
      AUTHENTIC:  'This image appears authentic. Save it to your Evidence Vault immediately as part of your complaint.',
      SUSPICIOUS: 'The image has some inconsistencies. Cross-check it against the original conversation before relying on it.',
      FABRICATED: 'This image shows signs of manipulation. Do not use it as primary evidence — capture a fresh screenshot from the original source.',
    };
    appendMessage(
      fallbacks[(result.verdict || 'SUSPICIOUS').toUpperCase()] || fallbacks.SUSPICIOUS,
      'assistant'
    );
  }
}

// ============================================================
// UI HELPERS
// ============================================================

// Show / hide loading spinner
function showLoading(visible) {
  loadingState.style.display  = visible ? 'flex' : 'none';
  messagesList.style.display  = visible ? 'none' : 'flex';
}

// Enable the input after load
function enableInput() {
  chatInput.disabled = false;
  chatInput.focus();
}

// Append a chat bubble
// ... format message ...
function appendMessage(text, role, scroll = true) {
  const wrapper = document.createElement('div');
  wrapper.className = `message-wrapper ${role}`;

  const bubble = document.createElement('div');
  bubble.className = 'message-bubble';
  bubble.innerHTML = formatMarkdown(text);

  const time = document.createElement('span');
  time.className   = 'message-time';
  time.textContent = timeNow();

  wrapper.appendChild(bubble);
  wrapper.appendChild(time);
  messagesList.appendChild(wrapper);
  if (scroll) scrollToBottom();
  return wrapper;
}

// Append the three-dot typing indicator
function appendTypingIndicator() {
  const wrapper = document.createElement('div');
  wrapper.className = 'message-wrapper assistant typing-indicator-wrapper';
  wrapper.innerHTML = `
    <div class="message-bubble">
      <span class="typing-dot"></span>
      <span class="typing-dot"></span>
      <span class="typing-dot"></span>
    </div>`;
  messagesList.appendChild(wrapper);
  scrollToBottom();
  return wrapper;
}

function scrollToBottom() {
  chatBody.scrollTop = chatBody.scrollHeight;
}

// Show a fatal error in the message area
function showError(msg) {
  showLoading(false);
  appendMessage(`⚠️ **Connection Error**\n\n${msg}`, 'assistant');
  enableInput();
}

// Current time string HH:MM
function timeNow() {
  return new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

// Escape HTML special characters
function escapeHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;')
    .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

// Basic markdown → HTML (bold, bullet lists, line breaks)
function formatMarkdown(text) {
  if (!text) return '';

  // Escape first to prevent XSS
  let html = escapeHtml(text);

  // Bold **text**
  html = html.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');

  // Bullet list lines starting with - or *
  const lines = html.split('\n');
  let inList = false;
  const processed = lines.map(line => {
    const t = line.trim();
    if (t.startsWith('- ') || t.startsWith('* ')) {
      const content = t.slice(2);
      if (!inList) { inList = true; return `<ul><li>${content}</li>`; }
      return `<li>${content}</li>`;
    }
    if (inList) { inList = false; return `</ul>${line}<br>`; }
    return line + '<br>';
  });
  html = processed.join('');
  if (inList) html += '</ul>';

  return html;
}
