// ============================================================
// SafeSphere Background Service Worker
// Handles: context menus, window management, proxy fetch,
// and routing both "text selected" + "no text" scenarios.
// ============================================================

'use strict';

const BACKEND = 'http://127.0.0.1:8081';

// ── Track the single SafeGuide popup window ─────────────────────────────
let safeGuideWindowId = null;

// ── On extension install: register context menu items ───────────────────
chrome.runtime.onInstalled.addListener(() => {
  // Right-click on selected text → run the overlay analysis
  chrome.contextMenus.create({
    id:       'safesphere-inspect',
    title:    'Analyze with SafeSphere',
    contexts: ['selection'],
  });

  // Right-click anywhere (with or without selection) → open SafeGuide chat
  chrome.contextMenus.create({
    id:       'safeguide-chat',
    title:    'Chat with SafeGuide AI',
    contexts: ['page', 'selection'],
  });
});

// ── Clean up window ID when the popup is closed ──────────────────────────
chrome.windows.onRemoved.addListener(windowId => {
  if (windowId === safeGuideWindowId) safeGuideWindowId = null;
});

// ============================================================
// WINDOW MANAGEMENT
// Open a new popup or focus/reload the existing one.
// ============================================================
function openOrFocusSafeGuide(url) {
  if (safeGuideWindowId !== null) {
    // Check the window still exists
    chrome.windows.get(safeGuideWindowId, win => {
      if (chrome.runtime.lastError || !win) {
        // Window was closed externally — create fresh
        createSafeGuideWindow(url);
        return;
      }
      // Re-use: navigate the existing tab to the new URL and bring to front
      chrome.tabs.query({ windowId: safeGuideWindowId }, tabs => {
        if (tabs && tabs[0]) chrome.tabs.update(tabs[0].id, { url });
      });
      chrome.windows.update(safeGuideWindowId, { focused: true });
    });
  } else {
    createSafeGuideWindow(url);
  }
}

function createSafeGuideWindow(url) {
  const width  = 440;
  const height = 640;

  chrome.windows.create({ url, type: 'popup', width, height }, win => {
    if (win) {
      safeGuideWindowId = win.id;
    }
  });
}

// ============================================================
// BUILD SAFEGUIDE URL
// Scenario A — text selected  → /chat.html?text=…&platform=…&context=…
// Scenario B — no text        → /chat.html  (greeting mode)
// ============================================================
function buildChatUrl(text, platform, context) {
  const base = chrome.runtime.getURL('chat.html');
  if (!text) return base;
  const params = new URLSearchParams({ text, platform: platform || 'Webpage', context: context || '' });
  return `${base}?${params.toString()}`;
}

// ── Detect platform from tab URL ─────────────────────────────────────────
function detectPlatformFromUrl(url) {
  if (!url) return 'Webpage';
  if (url.includes('instagram.com'))                        return 'Instagram';
  if (url.includes('discord.com'))                          return 'Discord';
  if (url.includes('whatsapp.com'))                         return 'WhatsApp';
  if (url.includes('reddit.com'))                           return 'Reddit';
  if (url.includes('twitter.com') || url.includes('x.com')) return 'X (Twitter)';
  if (url.includes('facebook.com'))                         return 'Facebook';
  if (url.includes('snapchat.com'))                         return 'Snapchat';
  if (url.includes('telegram.org'))                         return 'Telegram';
  if (url.includes('tiktok.com'))                           return 'TikTok';
  return 'Webpage';
}

// ============================================================
// CONTEXT MENU CLICK HANDLER
// ============================================================
chrome.contextMenus.onClicked.addListener((info, tab) => {

  // ── "Analyze with SafeSphere" — shows inline overlay card ───────────
  if (info.menuItemId === 'safesphere-inspect' && info.selectionText) {
    chrome.tabs.sendMessage(tab.id, {
      action: 'analyze_text',
      text:   info.selectionText,
    });
    return;
  }

  // ── "Chat with SafeGuide AI" ─────────────────────────────────────────
  if (info.menuItemId === 'safeguide-chat') {
    const platform = detectPlatformFromUrl(tab?.url);

    if (info.selectionText) {
      // Scenario A: text selected — ask content script for surrounding context
      chrome.tabs.sendMessage(
        tab.id,
        { action: 'get_chat_context', text: info.selectionText },
        response => {
          const context = response?.context || '';
          openOrFocusSafeGuide(buildChatUrl(info.selectionText, platform, context));
        }
      );
    } else {
      // Scenario B: no text — open greeting
      openOrFocusSafeGuide(buildChatUrl(null));
    }
  }
});

// ============================================================
// RUNTIME MESSAGE HANDLER
// Handles messages from content.js and chat.js
// ============================================================
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {

  // ── proxy_fetch: called by content.js for inline overlay analysis ────
  if (message.action === 'proxy_fetch') {
    fetch(`${BACKEND}/api/analyze`, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ text: message.text }),
    })
      .then(async res => {
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Network error');
        sendResponse({ data });
      })
      .catch(err => sendResponse({ error: err.message }));
    return true; // async
  }

  // ── openSafeGuide: called by content.js floating button click ────────
  if (message.action === 'openSafeGuide') {
    if (message.text) {
      // Scenario A: floating button clicked while text was highlighted
      openOrFocusSafeGuide(
        buildChatUrl(message.text, message.platform || 'Webpage', message.context || '')
      );
    } else {
      // Scenario B: no text selected — greeting
      openOrFocusSafeGuide(buildChatUrl(null));
    }
    sendResponse({ success: true });
    return true;
  }
});
